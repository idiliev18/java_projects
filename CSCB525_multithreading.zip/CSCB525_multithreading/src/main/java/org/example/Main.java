package org.example;

import config.ExecutorServiceConfig;
import model.Buyer;
import model.CartItem;
import model.Product;
import model.SaleResult;
import store.StoreInventory;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;

public class Main {
    public static void main(String[] args) {
        Map<Integer, Product> catalog = new LinkedHashMap<>();
        catalog.put(1, new Product(1, "Свински врат"));
        catalog.put(2, new Product(2, "Пилешки бут, без бут"));

        // 2. Зареждаме склада (Слаба наличност - ще има драма!)
        Map<Integer, Integer> initialStock = new LinkedHashMap<>();
        initialStock.put(1, 12); // Само 12 броя
        initialStock.put(2, 6);  // Само 6 броя

        StoreInventory store = new StoreInventory(catalog, initialStock);

        // 3. Списък с купувачи и техните хардкоднати кошници
        List<Buyer> buyers = new ArrayList<>(List.of(
                new Buyer(1, "Преслава", new ArrayList<>(List.of(new CartItem(1, 2), new CartItem(2, 1)))), // 2 врат, 1 бут
                new Buyer(2, "Галена", new ArrayList<>(List.of(new CartItem(1, 5)))),                       // 5 врат
                new Buyer(3, "Анелия", new ArrayList<>(List.of(new CartItem(2, 3)))),                       // 3 бута
                new Buyer(4, "Емилия", new ArrayList<>(List.of(new CartItem(1, 3), new CartItem(2, 2)))), // 3 врат, 2 бута (Тук бутовете свършват!)
                new Buyer(5, "Ивана", new ArrayList<>(List.of(new CartItem(1, 10)))),                      // Иска 10 врата (Няма да има!)
                new Buyer(6, "Глория", new ArrayList<>(List.of(new CartItem(1, 1)))),
                new Buyer(7, "Деси Слава", new ArrayList<>(List.of(new CartItem(2, 5)))),                   // Иска 5 бута (Вече са свършили)
                new Buyer(8, "Камелия", new ArrayList<>(List.of(new CartItem(1, 1)))),
                new Buyer(9, "Андреа", new ArrayList<>(List.of(new CartItem(1, 1)))),
                new Buyer(10, "Райна", new ArrayList<>(List.of(new CartItem(2, 1))))
        ));

        ExecutorService executor = ExecutorServiceConfig.getExecutorService();

        List<CompletableFuture<SaleResult>> futures = new ArrayList<>();

        for (Buyer buyer : buyers) {
            CompletableFuture<SaleResult> f = CompletableFuture.supplyAsync(()->{
                SaleResult sr = null;
                sr = store.sellAllOrNothing(buyer);

                return sr;
            }, executor);

            futures.add(f);
        }

        CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();

        executor.shutdown();


    }
}
