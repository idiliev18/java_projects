package org.example;

import java.time.LocalTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Най-простият вариант:
 * - 2 продукта
 * - 2 купувача
 * - CompletableFuture + FixedThreadPool(4) (като от zip-а)
 * - Variant A (всичко или нищо)
 * - Логове на човешки език
 *
 * Стартиране:
 *   javac ShopTwoByTwoDemo.java
 *   java ShopTwoByTwoDemo
 */
public class Preslava {

    // 1) "като от zip-а" - 4 нишки
    static final class ExecutorServiceConfig {
        private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(4);
        private ExecutorServiceConfig() {}
        public static ExecutorService getExecutorService() { return EXECUTOR; }
    }

    // 2) Модели
    static final class Product {
        final int id;
        final String name;
        Product(int id, String name) { this.id = id; this.name = name; }
    }

    static final class CartItem {
        final int productId;
        final int qty;
        CartItem(int productId, int qty) { this.productId = productId; this.qty = qty; }
    }

    static final class Buyer {
        final int id;
        final String name;
        final List<CartItem> cart;
        Buyer(int id, String name, List<CartItem> cart) {
            this.id = id; this.name = name; this.cart = cart;
        }
    }

    static final class SaleResult {
        final int buyerId;
        final boolean success;
        final String message;
        SaleResult(int buyerId, boolean success, String message) {
            this.buyerId = buyerId; this.success = success; this.message = message;
        }
    }

    // 3) Склад (Variant A) "като от zip-а": synchronized метод
    static final class StoreInventory {
        private final Map<Integer, Integer> stockByProductId = new LinkedHashMap<>();
        private final Map<Integer, Product> catalogById;

        StoreInventory(Map<Integer, Product> catalogById, Map<Integer, Integer> initialStock) {
            this.catalogById = catalogById;
            this.stockByProductId.putAll(initialStock);
        }

        /**
         * Variant A: Купувачът купува САМО ако има за всички неща в кошницата.
         * synchronized = докато обслужваме този купувач, никой друг не може да променя склада.
         */
        public synchronized SaleResult sellAllOrNothing(Buyer buyer) {
            log("МАГАЗИН", "Започвам да обслужвам " + buyer.name + ". Заключвам склада, за да няма бъркотия.");

            log("МАГАЗИН", "Наличности в момента: " + stockToHumanString());

            // 1) Проверка дали има за всичко
            log("МАГАЗИН", "Проверявам дали има достатъчно стока за цялата кошница на " + buyer.name + "...");
            for (CartItem item : buyer.cart) {
                Product p = catalogById.get(item.productId);
                String pname = (p == null) ? ("стока#" + item.productId) : p.name;

                int available = stockByProductId.getOrDefault(item.productId, 0);
                int requested = item.qty;

                log("МАГАЗИН", "  - " + buyer.name + " иска: " + pname + " x" + requested + ". Налични: " + available + ".");

                if (available < requested) {
                    int missing = requested - available;
                    String msg = "Няма достатъчно " + pname + ". Липсват " + missing + " броя. Нищо не продавам (всичко или нищо).";
                    log("МАГАЗИН", msg);
                    log("МАГАЗИН", "Оставям склада непроменен: " + stockToHumanString());
                    log("МАГАЗИН", "Приключвам с " + buyer.name + ". Отключвам склада.");
                    return new SaleResult(buyer.id, false, msg);
                }
            }

            // 2) Ако стига за всичко -> намаляваме
            log("МАГАЗИН", "Има достатъчно за всичко. Продавам цялата кошница на " + buyer.name + ".");
            for (CartItem item : buyer.cart) {
                Product p = catalogById.get(item.productId);
                String pname = (p == null) ? ("стока#" + item.productId) : p.name;

                int before = stockByProductId.getOrDefault(item.productId, 0);
                int after = before - item.qty;
                stockByProductId.put(item.productId, after);

                log("МАГАЗИН", "  - Намалявам " + pname + ": " + before + " -> " + after + " (минус " + item.qty + ").");
            }

            log("МАГАЗИН", "Готово. Нови наличности: " + stockToHumanString());
            log("МАГАЗИН", "Приключвам с " + buyer.name + ". Отключвам склада.");
            return new SaleResult(buyer.id, true, "Успешна покупка. Продадох цялата кошница.");
        }

        public synchronized String stockToHumanString() {
            Product p1 = catalogById.get(1);
            Product p2 = catalogById.get(2);
            String n1 = p1 == null ? "стока#1" : p1.name;
            String n2 = p2 == null ? "стока#2" : p2.name;

            int q1 = stockByProductId.getOrDefault(1, 0);
            int q2 = stockByProductId.getOrDefault(2, 0);

            return "{ " + n1 + "=" + q1 + ", " + n2 + "=" + q2 + " }";
        }
    }

    // 4) Main
    public static void mainkur(String[] args) {
        log("ГЛАВНО", "Старт на програмата.");

        // Два продукта
        Map<Integer, Product> catalog = new LinkedHashMap<>();
        catalog.put(1, new Product(1, "Хляб"));
        catalog.put(2, new Product(2, "Мляко"));

        // Малки наличности, за да има пример "не стига"
        // Хляб=3, Мляко=1
        Map<Integer, Integer> initialStock = new LinkedHashMap<>();
        initialStock.put(1, 3);
        initialStock.put(2, 1);

        StoreInventory store = new StoreInventory(catalog, initialStock);
        log("ГЛАВНО", "Начални наличности в магазина: " + store.stockToHumanString());

        // Два купувача:
        // Купувач 1 купува: Хляб x2 (успех)
        // Купувач 2 купува: Хляб x2 + Мляко x1 (може да FAIL, ако хлябът вече не стига)
        Buyer buyer1 = new Buyer(1, "Клиент 1", List.of(
                new CartItem(1, 2) // Хляб x2
        ));

        Buyer buyer2 = new Buyer(2, "Клиент 2", List.of(
                new CartItem(1, 2), // Хляб x2
                new CartItem(2, 1)  // Мляко x1
        ));

        ExecutorService executor = ExecutorServiceConfig.getExecutorService();
        log("ГЛАВНО", "Пускам 2 покупки като задачи (в пул от 4 нишки).");

        CompletableFuture<SaleResult> f1 = CompletableFuture.supplyAsync(() -> {
            log("ЗАДАЧА", "Започва обработка на " + buyer1.name + " в нишка: " + Thread.currentThread().getName());
            // Малко изчакване за да се види, че са конкурентни
            sleepSilently(200);
            SaleResult r = store.sellAllOrNothing(buyer1);
            log("ЗАДАЧА", buyer1.name + " приключи: " + (r.success ? "УСПЕХ" : "ОТКАЗ") + ". " + r.message);
            return r;
        }, executor);

        CompletableFuture<SaleResult> f2 = CompletableFuture.supplyAsync(() -> {
            log("ЗАДАЧА", "Започва обработка на " + buyer2.name + " в нишка: " + Thread.currentThread().getName());
            sleepSilently(300);
            SaleResult r = store.sellAllOrNothing(buyer2);
            log("ЗАДАЧА", buyer2.name + " приключи: " + (r.success ? "УСПЕХ" : "ОТКАЗ") + ". " + r.message);
            return r;
        }, executor);

        log("ГЛАВНО", "Чакам и двете покупки да приключат...");
        CompletableFuture.allOf(f1, f2).join();
        log("ГЛАВНО", "Двете покупки приключиха.");

        SaleResult r1 = f1.join();
        SaleResult r2 = f2.join();

        log("ГЛАВНО", "Резултат 1: " + (r1.success ? "УСПЕХ" : "ОТКАЗ") + " | " + r1.message);
        log("ГЛАВНО", "Резултат 2: " + (r2.success ? "УСПЕХ" : "ОТКАЗ") + " | " + r2.message);

        log("ГЛАВНО", "Крайни наличности в магазина: " + store.stockToHumanString());

        shutdownExecutor(executor);

        log("ГЛАВНО", "Край на програмата.");
    }

    // Utility
    private static void shutdownExecutor(ExecutorService executor) {
        log("ГЛАВНО", "Спирам пула с нишките (shutdown).");
        executor.shutdown();
        try {
            boolean ok = executor.awaitTermination(2, TimeUnit.SECONDS);
            if (!ok) {
                log("ГЛАВНО", "Не спря навреме -> shutdownNow().");
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            executor.shutdownNow();
        }
    }

    private static void sleepSilently(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private static void log(String tag, String msg) {
        System.out.println(LocalTime.now() + " [" + tag + "] [" + Thread.currentThread().getName() + "] " + msg);
    }
}
