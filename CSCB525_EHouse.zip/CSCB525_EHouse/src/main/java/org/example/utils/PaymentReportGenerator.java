package org.example.utils;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRParameter;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.example.report.PaymentReportRow;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PaymentReportGenerator {
    private static final String TEMPLATE_PATH = "/reports/payments_by_company.jrxml";
    private static final DateTimeFormatter GENERATED_AT_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public void generate(Path outputFile, List<PaymentReportRow> rows, LocalDateTime generatedAt) {
        JasperReport report = compileReport();
        JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(rows);
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("REPORT_TITLE", "Payments by Company");
        parameters.put("GENERATED_AT", generatedAt == null ? "" : generatedAt.format(GENERATED_AT_FORMAT));
        parameters.put(JRParameter.REPORT_LOCALE, java.util.Locale.US);

        try {
            JasperPrint print = JasperFillManager.fillReport(report, parameters, dataSource);
            Path parent = outputFile.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            JasperExportManager.exportReportToPdfFile(print, outputFile.toString());
        } catch (JRException | IOException e) {
            throw new RuntimeException("Failed to generate payment report: " + outputFile, e);
        }
    }

    private JasperReport compileReport() {
        try (InputStream template = PaymentReportGenerator.class.getResourceAsStream(TEMPLATE_PATH)) {
            if (template == null) {
                throw new IllegalStateException("Report template not found: " + TEMPLATE_PATH);
            }
            return JasperCompileManager.compileReport(template);
        } catch (JRException | IOException e) {
            throw new RuntimeException("Failed to compile payment report template.", e);
        }
    }
}
