package org.example.utils;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class PaymentFileWriter {
    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public void appendPayment(Path file,
                              String companyName,
                              String employeeName,
                              String buildingAddress,
                              String apartmentNumber,
                              BigDecimal amount,
                              LocalDateTime paymentDate) {
        String line = String.join(" | ",
                safe(companyName),
                safe(employeeName),
                safe(buildingAddress),
                safe(apartmentNumber),
                amount == null ? "0" : amount.toString(),
                paymentDate == null ? "" : paymentDate.format(FORMAT)
        );
        try {
            Files.writeString(
                    file,
                    line + System.lineSeparator(),
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.APPEND
            );
        } catch (IOException e) {
            throw new RuntimeException("Failed to write payment file: " + file, e);
        }
    }

    private String safe(String s) {
        return s == null ? "" : s;
    }
}
