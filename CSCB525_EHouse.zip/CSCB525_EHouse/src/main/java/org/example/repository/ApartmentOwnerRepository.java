package org.example.repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.example.entity.ApartmentOwner;
import org.example.util.JpaUtil;

import java.util.List;

public class ApartmentOwnerRepository implements IApartmentOwnerRepository {
    public ApartmentOwner save(ApartmentOwner ownerLink) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(ownerLink);
            em.getTransaction().commit();
            return ownerLink;
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }

    public ApartmentOwner findById(Long id) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            return em.find(ApartmentOwner.class, id);
        } finally {
            em.close();
        }
    }

    public List<ApartmentOwner> findAll() {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<ApartmentOwner> query = em.createQuery(
                    "SELECT ao FROM ApartmentOwner ao ORDER BY ao.id", ApartmentOwner.class);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public ApartmentOwner update(ApartmentOwner ownerLink) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            ApartmentOwner merged = em.merge(ownerLink);
            em.getTransaction().commit();
            return merged;
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }

    public boolean existsByApartmentAndPerson(Long apartmentId, Long personId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            Long count = em.createQuery(
                            "SELECT COUNT(ao) FROM ApartmentOwner ao " +
                                    "WHERE ao.apartment.id = :apartmentId AND ao.person.id = :personId",
                            Long.class)
                    .setParameter("apartmentId", apartmentId)
                    .setParameter("personId", personId)
                    .getSingleResult();
            return count != null && count > 0;
        } finally {
            em.close();
        }
    }

    public boolean existsByApartmentAndPersonExcludingId(Long apartmentId, Long personId, Long excludedId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            Long count = em.createQuery(
                            "SELECT COUNT(ao) FROM ApartmentOwner ao " +
                                    "WHERE ao.apartment.id = :apartmentId AND ao.person.id = :personId " +
                                    "AND ao.id <> :excludedId",
                            Long.class)
                    .setParameter("apartmentId", apartmentId)
                    .setParameter("personId", personId)
                    .setParameter("excludedId", excludedId)
                    .getSingleResult();
            return count != null && count > 0;
        } finally {
            em.close();
        }
    }

    public void deleteById(Long id) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            ApartmentOwner ownerLink = em.find(ApartmentOwner.class, id);
            if (ownerLink != null) {
                em.remove(ownerLink);
            }
            em.getTransaction().commit();
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }
}
