package org.example.repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.example.entity.Contract;
import org.example.util.JpaUtil;

import java.util.List;

public class ContractRepository implements IContractRepository {
    public Contract save(Contract contract) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(contract);
            em.getTransaction().commit();
            return contract;
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }

    public Contract update(Contract contract) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            Contract merged = em.merge(contract);
            em.getTransaction().commit();
            return merged;
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }

    public Contract findById(Long id) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            return em.find(Contract.class, id);
        } finally {
            em.close();
        }
    }

    public Contract findByCompanyAndBuilding(Long companyId, Long buildingId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Contract> query = em.createQuery(
                    "SELECT c FROM Contract c WHERE c.company.id = :companyId AND c.building.id = :buildingId",
                    Contract.class);
            query.setParameter("companyId", companyId);
            query.setParameter("buildingId", buildingId);
            List<Contract> results = query.getResultList();
            return results.isEmpty() ? null : results.get(0);
        } finally {
            em.close();
        }
    }

    public List<Contract> findByCompanyAndEmployee(Long companyId, Long employeeId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Contract> query = em.createQuery(
                    "SELECT c FROM Contract c WHERE c.company.id = :companyId AND c.employee.id = :employeeId",
                    Contract.class);
            query.setParameter("companyId", companyId);
            query.setParameter("employeeId", employeeId);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public List<Contract> findByCompany(Long companyId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Contract> query = em.createQuery(
                    "SELECT c FROM Contract c WHERE c.company.id = :companyId",
                    Contract.class);
            query.setParameter("companyId", companyId);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public List<Contract> findByIdsWithDetails(List<Long> ids) {
        if (ids == null || ids.isEmpty()) {
            return List.of();
        }
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Contract> query = em.createQuery(
                    "SELECT c FROM Contract c " +
                            "JOIN FETCH c.company " +
                            "JOIN FETCH c.building " +
                            "JOIN FETCH c.employee " +
                            "WHERE c.id IN :ids " +
                            "ORDER BY c.id",
                    Contract.class);
            query.setParameter("ids", ids);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public Contract findByBuilding(Long buildingId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Contract> query = em.createQuery(
                    "SELECT c FROM Contract c WHERE c.building.id = :buildingId",
                    Contract.class);
            query.setParameter("buildingId", buildingId);
            List<Contract> results = query.setMaxResults(2).getResultList();
            if (results.isEmpty()) {
                return null;
            }
            if (results.size() > 1) {
                throw new IllegalStateException("Multiple contracts found for building id=" + buildingId);
            }
            return results.get(0);
        } finally {
            em.close();
        }
    }
}
