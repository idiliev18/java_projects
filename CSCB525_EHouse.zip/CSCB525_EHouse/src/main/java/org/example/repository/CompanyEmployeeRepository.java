package org.example.repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.example.entity.CompanyEmployee;
import org.example.util.JpaUtil;

import java.util.List;

public class CompanyEmployeeRepository implements ICompanyEmployeeRepository {
    public CompanyEmployee save(CompanyEmployee link) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(link);
            em.getTransaction().commit();
            return link;
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }

    public CompanyEmployee findById(Long id) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            return em.find(CompanyEmployee.class, id);
        } finally {
            em.close();
        }
    }

    public List<CompanyEmployee> findAll() {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<CompanyEmployee> query = em.createQuery(
                    "SELECT ce FROM CompanyEmployee ce ORDER BY ce.id", CompanyEmployee.class);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public CompanyEmployee update(CompanyEmployee link) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            CompanyEmployee merged = em.merge(link);
            em.getTransaction().commit();
            return merged;
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }

    public boolean existsByCompanyAndPerson(Long companyId, Long personId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            Long count = em.createQuery(
                            "SELECT COUNT(ce) FROM CompanyEmployee ce " +
                                    "WHERE ce.company.id = :companyId AND ce.person.id = :personId",
                            Long.class)
                    .setParameter("companyId", companyId)
                    .setParameter("personId", personId)
                    .getSingleResult();
            return count != null && count > 0;
        } finally {
            em.close();
        }
    }

    public boolean existsByCompanyAndPersonExcludingId(Long companyId, Long personId, Long excludedId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            Long count = em.createQuery(
                            "SELECT COUNT(ce) FROM CompanyEmployee ce " +
                                    "WHERE ce.company.id = :companyId AND ce.person.id = :personId " +
                                    "AND ce.id <> :excludedId",
                            Long.class)
                    .setParameter("companyId", companyId)
                    .setParameter("personId", personId)
                    .setParameter("excludedId", excludedId)
                    .getSingleResult();
            return count != null && count > 0;
        } finally {
            em.close();
        }
    }

    public void deleteById(Long id) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            CompanyEmployee link = em.find(CompanyEmployee.class, id);
            if (link != null) {
                em.remove(link);
            }
            em.getTransaction().commit();
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }
}
