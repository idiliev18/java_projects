package org.example.repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.example.entity.ApartmentResident;
import org.example.util.JpaUtil;

import java.util.List;

public class ApartmentResidentRepository implements IApartmentResidentRepository {
    public ApartmentResident save(ApartmentResident residentLink) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(residentLink);
            em.getTransaction().commit();
            return residentLink;
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }

    public ApartmentResident findById(Long id) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            return em.find(ApartmentResident.class, id);
        } finally {
            em.close();
        }
    }

    public List<ApartmentResident> findAll() {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<ApartmentResident> query = em.createQuery(
                    "SELECT ar FROM ApartmentResident ar ORDER BY ar.id", ApartmentResident.class);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public ApartmentResident update(ApartmentResident residentLink) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            ApartmentResident merged = em.merge(residentLink);
            em.getTransaction().commit();
            return merged;
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }

    public boolean existsByApartmentAndPerson(Long apartmentId, Long personId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            Long count = em.createQuery(
                            "SELECT COUNT(ar) FROM ApartmentResident ar " +
                                    "WHERE ar.apartment.id = :apartmentId AND ar.person.id = :personId",
                            Long.class)
                    .setParameter("apartmentId", apartmentId)
                    .setParameter("personId", personId)
                    .getSingleResult();
            return count != null && count > 0;
        } finally {
            em.close();
        }
    }

    public boolean existsByApartmentAndPersonExcludingId(Long apartmentId, Long personId, Long excludedId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            Long count = em.createQuery(
                            "SELECT COUNT(ar) FROM ApartmentResident ar " +
                                    "WHERE ar.apartment.id = :apartmentId AND ar.person.id = :personId " +
                                    "AND ar.id <> :excludedId",
                            Long.class)
                    .setParameter("apartmentId", apartmentId)
                    .setParameter("personId", personId)
                    .setParameter("excludedId", excludedId)
                    .getSingleResult();
            return count != null && count > 0;
        } finally {
            em.close();
        }
    }

    public void deleteById(Long id) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            ApartmentResident residentLink = em.find(ApartmentResident.class, id);
            if (residentLink != null) {
                em.remove(residentLink);
            }
            em.getTransaction().commit();
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }
}
