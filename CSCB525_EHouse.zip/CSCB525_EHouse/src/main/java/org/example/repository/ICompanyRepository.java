package org.example.repository;

import org.example.entity.Company;

import java.util.List;

public interface ICompanyRepository {
    Company save(Company company);

    Company findById(Long id);

    List<Company> findAll();

    Company update(Company company);

    void deleteById(Long id);
}
