package org.example.repository;

import org.example.entity.CompanyEmployee;

import java.util.List;

public interface ICompanyEmployeeRepository {
    CompanyEmployee save(CompanyEmployee link);

    CompanyEmployee findById(Long id);

    List<CompanyEmployee> findAll();

    CompanyEmployee update(CompanyEmployee link);

    void deleteById(Long id);

    boolean existsByCompanyAndPerson(Long companyId, Long personId);

    boolean existsByCompanyAndPersonExcludingId(Long companyId, Long personId, Long excludedId);
}
