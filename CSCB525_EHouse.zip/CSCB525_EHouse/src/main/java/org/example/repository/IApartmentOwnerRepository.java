package org.example.repository;

import org.example.entity.ApartmentOwner;

import java.util.List;

public interface IApartmentOwnerRepository {
    ApartmentOwner save(ApartmentOwner ownerLink);

    ApartmentOwner findById(Long id);

    List<ApartmentOwner> findAll();

    ApartmentOwner update(ApartmentOwner ownerLink);

    void deleteById(Long id);

    boolean existsByApartmentAndPerson(Long apartmentId, Long personId);

    boolean existsByApartmentAndPersonExcludingId(Long apartmentId, Long personId, Long excludedId);
}
