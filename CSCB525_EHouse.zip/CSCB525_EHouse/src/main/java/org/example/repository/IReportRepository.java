package org.example.repository;

import org.example.entity.Apartment;
import org.example.entity.ApartmentResident;
import org.example.entity.Building;
import org.example.entity.Person;

import java.util.List;

public interface IReportRepository {
    List<Object[]> fetchCompaniesRevenue();

    List<Building> findAllBuildings();

    List<Object[]> fetchBuildingsPaid();

    List<Person> findEmployeesByCompany(Long companyId);

    List<Object[]> fetchEmployeesPaid(Long companyId);

    List<Object[]> fetchCompaniesWithEmployees();

    List<Object[]> fetchEmployeesByNameWithBuildingCounts(Long companyId);

    List<Object[]> fetchEmployeesByBuildingCount(Long companyId);

    List<Object[]> fetchBuildingsByEmployees(Long companyId);

    List<Apartment> findApartmentsByBuilding(Long buildingId);

    List<Object[]> fetchApartmentsForPeople();

    List<Object[]> fetchOwnersForPeople();

    List<Object[]> fetchResidentsForPeople();

    List<Person> findResidentsByName(Long buildingId);

    List<Person> findResidentsByAge(Long buildingId);

    double sumApartmentAreas(Long buildingId);

    int sumApartmentPets(Long buildingId);

    List<ApartmentResident> findResidentsByBuilding(Long buildingId);
}
