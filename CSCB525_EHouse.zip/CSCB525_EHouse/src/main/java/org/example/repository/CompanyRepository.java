package org.example.repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.example.entity.Company;
import org.example.util.JpaUtil;

import java.util.List;

public class CompanyRepository implements ICompanyRepository {
    public Company save(Company company) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(company);
            em.getTransaction().commit();
            return company;
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }

    public Company findById(Long id) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            return em.find(Company.class, id);
        } finally {
            em.close();
        }
    }

    public List<Company> findAll() {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Company> query = em.createQuery("SELECT c FROM Company c ORDER BY c.id", Company.class);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public Company update(Company company) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            Company merged = em.merge(company);
            em.getTransaction().commit();
            return merged;
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }

    public void deleteById(Long id) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            Company company = em.find(Company.class, id);
            if (company != null) {
                em.remove(company);
            }
            em.getTransaction().commit();
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }
}
