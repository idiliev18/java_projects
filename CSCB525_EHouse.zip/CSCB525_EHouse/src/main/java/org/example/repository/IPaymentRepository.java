package org.example.repository;

import org.example.entity.Payment;

import java.util.List;

public interface IPaymentRepository {
    Payment save(Payment payment);

    Payment findById(Long id);

    List<Payment> findAll();
}
