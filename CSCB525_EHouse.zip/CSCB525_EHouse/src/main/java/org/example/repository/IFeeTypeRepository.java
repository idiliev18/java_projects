package org.example.repository;

import org.example.entity.FeeType;

public interface IFeeTypeRepository {
    FeeType save(FeeType feeType);

    FeeType findById(Long id);

    FeeType findByName(String name);
}
