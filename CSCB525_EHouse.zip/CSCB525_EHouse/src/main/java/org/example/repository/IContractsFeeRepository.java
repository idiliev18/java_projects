package org.example.repository;

import org.example.entity.ContractsFee;

import java.util.List;

public interface IContractsFeeRepository {
    ContractsFee save(ContractsFee fee);

    List<ContractsFee> findByContractId(Long contractId);

    List<ContractsFee> findByContractIdOrdered(Long contractId);

    ContractsFee findByContractAndFeeType(Long contractId, Long feeTypeId);

    ContractsFee update(ContractsFee fee);
}
