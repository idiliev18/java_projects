package org.example.repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.example.entity.ContractsFee;
import org.example.util.JpaUtil;

import java.util.List;

public class ContractsFeeRepository implements IContractsFeeRepository {
    public ContractsFee save(ContractsFee fee) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(fee);
            em.getTransaction().commit();
            return fee;
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }

    public List<ContractsFee> findByContractId(Long contractId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<ContractsFee> query = em.createQuery(
                    "SELECT cf FROM ContractsFee cf WHERE cf.contract.id = :contractId",
                    ContractsFee.class);
            query.setParameter("contractId", contractId);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public List<ContractsFee> findByContractIdOrdered(Long contractId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<ContractsFee> query = em.createQuery(
                    "SELECT cf FROM ContractsFee cf WHERE cf.contract.id = :contractId ORDER BY cf.id",
                    ContractsFee.class);
            query.setParameter("contractId", contractId);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public ContractsFee findByContractAndFeeType(Long contractId, Long feeTypeId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<ContractsFee> query = em.createQuery(
                    "SELECT cf FROM ContractsFee cf WHERE cf.contract.id = :contractId AND cf.feeType.id = :feeTypeId",
                    ContractsFee.class);
            query.setParameter("contractId", contractId);
            query.setParameter("feeTypeId", feeTypeId);
            List<ContractsFee> results = query.getResultList();
            return results.isEmpty() ? null : results.get(0);
        } finally {
            em.close();
        }
    }

    public ContractsFee update(ContractsFee fee) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            ContractsFee merged = em.merge(fee);
            em.getTransaction().commit();
            return merged;
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }
}
