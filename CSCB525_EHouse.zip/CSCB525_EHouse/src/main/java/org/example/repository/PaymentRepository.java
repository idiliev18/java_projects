package org.example.repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.example.entity.Payment;
import org.example.util.JpaUtil;

import java.util.List;

public class PaymentRepository implements IPaymentRepository {
    public Payment save(Payment payment) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(payment);
            em.getTransaction().commit();
            return payment;
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }

    public Payment findById(Long id) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            return em.find(Payment.class, id);
        } finally {
            em.close();
        }
    }

    public List<Payment> findAll() {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Payment> query = em.createQuery(
                    "SELECT p FROM Payment p ORDER BY p.id", Payment.class);
            return query.getResultList();
        } finally {
            em.close();
        }
    }
}
