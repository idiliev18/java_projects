package org.example.repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.example.entity.Apartment;
import org.example.util.JpaUtil;

import java.util.List;

public class ApartmentRepository implements IApartmentRepository {
    public Apartment save(Apartment apartment) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(apartment);
            em.getTransaction().commit();
            return apartment;
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }

    public Apartment findById(Long id) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            return em.find(Apartment.class, id);
        } finally {
            em.close();
        }
    }

    public List<Apartment> findAll() {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Apartment> query = em.createQuery(
                    "SELECT a FROM Apartment a ORDER BY a.id", Apartment.class);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public Apartment update(Apartment apartment) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            Apartment merged = em.merge(apartment);
            em.getTransaction().commit();
            return merged;
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }

    public void deleteById(Long id) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            Apartment apartment = em.find(Apartment.class, id);
            if (apartment != null) {
                em.remove(apartment);
            }
            em.getTransaction().commit();
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }
}
