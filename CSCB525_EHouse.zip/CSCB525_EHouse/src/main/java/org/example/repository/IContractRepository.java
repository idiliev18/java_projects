package org.example.repository;

import org.example.entity.Contract;

import java.util.List;

public interface IContractRepository {
    Contract save(Contract contract);

    Contract update(Contract contract);

    Contract findById(Long id);

    Contract findByCompanyAndBuilding(Long companyId, Long buildingId);

    List<Contract> findByCompanyAndEmployee(Long companyId, Long employeeId);

    List<Contract> findByCompany(Long companyId);

    List<Contract> findByIdsWithDetails(List<Long> ids);

    Contract findByBuilding(Long buildingId);
}
