package org.example.repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.example.entity.FeeType;
import org.example.util.JpaUtil;

import java.util.List;

public class FeeTypeRepository implements IFeeTypeRepository {
    public FeeType save(FeeType feeType) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(feeType);
            em.getTransaction().commit();
            return feeType;
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }

    public FeeType findById(Long id) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            return em.find(FeeType.class, id);
        } finally {
            em.close();
        }
    }

    public FeeType findByName(String name) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<FeeType> query = em.createQuery(
                    "SELECT f FROM FeeType f WHERE f.name = :name", FeeType.class);
            query.setParameter("name", name);
            List<FeeType> results = query.getResultList();
            return results.isEmpty() ? null : results.get(0);
        } finally {
            em.close();
        }
    }
}
