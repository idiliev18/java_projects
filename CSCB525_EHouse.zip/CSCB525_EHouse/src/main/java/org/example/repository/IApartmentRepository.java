package org.example.repository;

import org.example.entity.Apartment;

import java.util.List;

public interface IApartmentRepository {
    Apartment save(Apartment apartment);

    Apartment findById(Long id);

    List<Apartment> findAll();

    Apartment update(Apartment apartment);

    void deleteById(Long id);
}
