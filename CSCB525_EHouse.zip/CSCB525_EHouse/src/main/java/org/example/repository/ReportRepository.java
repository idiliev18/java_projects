package org.example.repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.example.entity.Apartment;
import org.example.entity.ApartmentResident;
import org.example.entity.Building;
import org.example.entity.Person;
import org.example.util.JpaUtil;

import java.util.List;

public class ReportRepository implements IReportRepository {
    public List<Object[]> fetchCompaniesRevenue() {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Object[]> query = em.createQuery(
                    "SELECT c, COALESCE(SUM(p.amount), 0) " +
                            "FROM Company c " +
                            "LEFT JOIN Contract ct ON ct.company = c " +
                            "LEFT JOIN Apartment a ON a.building = ct.building " +
                            "LEFT JOIN Payment p ON p.apartment = a " +
                            "GROUP BY c.id, c.name " +
                            "ORDER BY COALESCE(SUM(p.amount), 0) DESC, c.id",
                    Object[].class);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public List<Building> findAllBuildings() {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Building> query = em.createQuery(
                    "SELECT b FROM Building b ORDER BY b.id", Building.class);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public List<Object[]> fetchBuildingsPaid() {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Object[]> query = em.createQuery(
                    "SELECT b, COALESCE(SUM(p.amount), 0) " +
                            "FROM Building b " +
                            "LEFT JOIN Apartment a ON a.building = b " +
                            "LEFT JOIN Payment p ON p.apartment = a " +
                            "GROUP BY b.id, b.address " +
                            "ORDER BY b.id",
                    Object[].class);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public List<Person> findEmployeesByCompany(Long companyId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Person> query = em.createQuery(
                    "SELECT DISTINCT p " +
                            "FROM CompanyEmployee ce " +
                            "JOIN ce.person p " +
                            "WHERE ce.company.id = :companyId " +
                            "ORDER BY p.firstName, p.lastName, p.id",
                    Person.class);
            query.setParameter("companyId", companyId);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public List<Object[]> fetchEmployeesPaid(Long companyId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Object[]> query = em.createQuery(
                    "SELECT p, COALESCE(SUM(pay.amount), 0) " +
                            "FROM CompanyEmployee ce " +
                            "JOIN ce.person p " +
                            "LEFT JOIN Contract c ON c.company = ce.company AND c.employee = p " +
                            "LEFT JOIN Apartment a ON a.building = c.building " +
                            "LEFT JOIN Payment pay ON pay.apartment = a " +
                            "WHERE ce.company.id = :companyId " +
                            "GROUP BY p.id, p.firstName, p.lastName " +
                            "ORDER BY p.firstName, p.lastName, p.id",
                    Object[].class);
            query.setParameter("companyId", companyId);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public List<Object[]> fetchCompaniesWithEmployees() {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Object[]> query = em.createQuery(
                    "SELECT c.id, c.name, p.firstName, p.lastName " +
                            "FROM Company c " +
                            "LEFT JOIN CompanyEmployee ce ON ce.company = c " +
                            "LEFT JOIN ce.person p " +
                            "ORDER BY c.name, p.firstName, p.lastName",
                    Object[].class);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public List<Object[]> fetchEmployeesByNameWithBuildingCounts(Long companyId) {
        return fetchEmployeesWithBuildingCounts(
                companyId,
                "ORDER BY p.firstName, p.lastName, p.id");
    }

    public List<Object[]> fetchEmployeesByBuildingCount(Long companyId) {
        return fetchEmployeesWithBuildingCounts(
                companyId,
                "ORDER BY COUNT(c) ASC, p.firstName, p.lastName, p.id");
    }

    public List<Object[]> fetchBuildingsByEmployees(Long companyId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Object[]> query = em.createQuery(
                    "SELECT p, b " +
                            "FROM Contract c " +
                            "JOIN c.employee p " +
                            "JOIN c.building b " +
                            "WHERE c.company.id = :companyId " +
                            "ORDER BY p.firstName, p.lastName, b.id",
                    Object[].class);
            query.setParameter("companyId", companyId);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public List<Apartment> findApartmentsByBuilding(Long buildingId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Apartment> query = em.createQuery(
                    "SELECT a FROM Apartment a WHERE a.building.id = :buildingId ORDER BY a.id",
                    Apartment.class);
            query.setParameter("buildingId", buildingId);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public List<Object[]> fetchApartmentsForPeople() {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Object[]> query = em.createQuery(
                    "SELECT a.id, a.number, b.address " +
                            "FROM Apartment a JOIN a.building b " +
                            "ORDER BY b.address, a.number, a.id",
                    Object[].class);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public List<Object[]> fetchOwnersForPeople() {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Object[]> query = em.createQuery(
                    "SELECT ao.apartment.id, p.firstName, p.lastName " +
                            "FROM ApartmentOwner ao JOIN ao.person p " +
                            "ORDER BY ao.apartment.id, p.firstName, p.lastName",
                    Object[].class);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public List<Object[]> fetchResidentsForPeople() {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Object[]> query = em.createQuery(
                    "SELECT ar.apartment.id, p.firstName, p.lastName " +
                            "FROM ApartmentResident ar JOIN ar.person p " +
                            "ORDER BY ar.apartment.id, p.firstName, p.lastName",
                    Object[].class);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public List<Person> findResidentsByName(Long buildingId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Person> query = em.createQuery(
                    "SELECT DISTINCT p " +
                            "FROM ApartmentResident ar " +
                            "JOIN ar.person p " +
                            "WHERE ar.apartment.building.id = :buildingId " +
                            "ORDER BY p.firstName, p.lastName, p.id",
                    Person.class);
            query.setParameter("buildingId", buildingId);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public List<Person> findResidentsByAge(Long buildingId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Person> query = em.createQuery(
                    "SELECT DISTINCT p " +
                            "FROM ApartmentResident ar " +
                            "JOIN ar.person p " +
                            "WHERE ar.apartment.building.id = :buildingId " +
                            "ORDER BY p.birthDate ASC, p.id",
                    Person.class);
            query.setParameter("buildingId", buildingId);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public double sumApartmentAreas(Long buildingId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Double> query = em.createQuery(
                    "SELECT COALESCE(SUM(a.area), 0) FROM Apartment a WHERE a.building.id = :buildingId",
                    Double.class);
            query.setParameter("buildingId", buildingId);
            return query.getSingleResult();
        } finally {
            em.close();
        }
    }

    public int sumApartmentPets(Long buildingId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Long> query = em.createQuery(
                    "SELECT COALESCE(SUM(a.petCount), 0) FROM Apartment a WHERE a.building.id = :buildingId",
                    Long.class);
            query.setParameter("buildingId", buildingId);
            Long result = query.getSingleResult();
            return result == null ? 0 : result.intValue();
        } finally {
            em.close();
        }
    }

    public List<ApartmentResident> findResidentsByBuilding(Long buildingId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<ApartmentResident> query = em.createQuery(
                    "SELECT ar FROM ApartmentResident ar WHERE ar.apartment.building.id = :buildingId",
                    ApartmentResident.class);
            query.setParameter("buildingId", buildingId);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    private List<Object[]> fetchEmployeesWithBuildingCounts(Long companyId, String orderBy) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Object[]> query = em.createQuery(
                    "SELECT p, COUNT(c) " +
                            "FROM CompanyEmployee ce " +
                            "JOIN ce.person p " +
                            "LEFT JOIN Contract c ON c.company = ce.company AND c.employee = p " +
                            "WHERE ce.company.id = :companyId " +
                            "GROUP BY p.id, p.firstName, p.lastName " +
                            orderBy,
                    Object[].class);
            query.setParameter("companyId", companyId);
            return query.getResultList();
        } finally {
            em.close();
        }
    }
}
