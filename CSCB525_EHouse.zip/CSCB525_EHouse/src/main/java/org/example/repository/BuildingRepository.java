package org.example.repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.example.entity.Building;
import org.example.util.JpaUtil;

import java.util.List;

public class BuildingRepository implements IBuildingRepository {
    public Building save(Building building) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(building);
            em.getTransaction().commit();
            return building;
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }

    public Building findById(Long id) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            return em.find(Building.class, id);
        } finally {
            em.close();
        }
    }

    public List<Building> findAll() {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Building> query = em.createQuery(
                    "SELECT b FROM Building b ORDER BY b.id", Building.class);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public Building update(Building building) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            Building merged = em.merge(building);
            em.getTransaction().commit();
            return merged;
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }

    public void deleteById(Long id) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            Building building = em.find(Building.class, id);
            if (building != null) {
                em.remove(building);
            }
            em.getTransaction().commit();
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }
}
