package org.example.repository;

import org.example.entity.Building;

import java.util.List;

public interface IBuildingRepository {
    Building save(Building building);

    Building findById(Long id);

    List<Building> findAll();

    Building update(Building building);

    void deleteById(Long id);
}
