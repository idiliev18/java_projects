package org.example.repository;

import org.example.entity.ApartmentResident;

import java.util.List;

public interface IApartmentResidentRepository {
    ApartmentResident save(ApartmentResident residentLink);

    ApartmentResident findById(Long id);

    List<ApartmentResident> findAll();

    ApartmentResident update(ApartmentResident residentLink);

    void deleteById(Long id);

    boolean existsByApartmentAndPerson(Long apartmentId, Long personId);

    boolean existsByApartmentAndPersonExcludingId(Long apartmentId, Long personId, Long excludedId);
}
