package org.example.service;

import org.example.entity.Payment;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.time.LocalDateTime;

public interface IPaymentService {
    Payment payApartment(Long apartmentId, BigDecimal amount, LocalDateTime paymentDate);

    Payment payApartment(Long apartmentId, BigDecimal amount, LocalDateTime paymentDate, Path filePath);

    BigDecimal calculateDueForApartment(Long apartmentId);
}
