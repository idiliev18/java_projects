package org.example.service;

import org.example.dto.ApartmentResidentUpdateRequest;
import org.example.entity.ApartmentResident;

import java.util.List;

public interface IApartmentResidentService {
    ApartmentResident addResidentToApartment(Long apartmentId, Long personId, boolean isLiftUsed);

    ApartmentResident updateResidentLink(Long id, ApartmentResidentUpdateRequest request);

    void removeResidentLink(Long id);

    ApartmentResident getResidentLink(Long id);

    List<ApartmentResident> getAllResidentLinks();
}
