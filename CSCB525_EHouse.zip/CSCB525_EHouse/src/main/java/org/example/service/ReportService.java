package org.example.service;

import org.example.entity.Apartment;
import org.example.entity.ApartmentResident;
import org.example.entity.Building;
import org.example.entity.Company;
import org.example.entity.Contract;
import org.example.entity.ContractsFee;
import org.example.entity.Person;
import org.example.repository.ICompanyRepository;
import org.example.repository.IContractRepository;
import org.example.repository.IContractsFeeRepository;
import org.example.repository.IReportRepository;
import org.example.repository.CompanyRepository;
import org.example.repository.ContractRepository;
import org.example.repository.ContractsFeeRepository;
import org.example.repository.ReportRepository;
import org.example.view.ApartmentPeopleView;
import org.example.view.ApartmentView;
import org.example.view.BuildingDueView;
import org.example.view.BuildingEmployeeView;
import org.example.view.BuildingPaidView;
import org.example.view.CompanyDueView;
import org.example.view.CompanyRevenueView;
import org.example.view.CompanyEmployeesView;
import org.example.view.EmployeeBuildingsView;
import org.example.view.EmployeeDueView;
import org.example.view.EmployeePaidView;
import org.example.view.ResidentView;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReportService implements IReportService {
    private final ICompanyRepository companyRepository = new CompanyRepository();
    private final IContractRepository contractRepository = new ContractRepository();
    private final IContractsFeeRepository contractsFeeRepository = new ContractsFeeRepository();
    private final IReportRepository reportRepository = new ReportRepository();

    public List<CompanyRevenueView> getCompaniesByRevenue() {
        List<Object[]> rows = reportRepository.fetchCompaniesRevenue();
        List<CompanyRevenueView> result = new ArrayList<>();
        for (Object[] row : rows) {
            var company = (Company) row[0];
            var revenue = (BigDecimal) row[1];
            result.add(new CompanyRevenueView(company, revenue));
        }
        return result;
    }

    public List<CompanyDueView> getCompaniesDue() {
        List<Company> companies = companyRepository.findAll();
        List<CompanyDueView> result = new ArrayList<>();
        for (Company c : companies) {
            BigDecimal due = totalDueForCompany(c.getId());
            result.add(new CompanyDueView(c, due));
        }
        return result;
    }

    public List<BuildingDueView> getBuildingsDue() {
        List<Building> buildings = reportRepository.findAllBuildings();
        List<BuildingDueView> result = new ArrayList<>();
        for (Building b : buildings) {
            BigDecimal due = calculateDueForBuilding(b.getId());
            result.add(new BuildingDueView(b, due));
        }
        return result;
    }

    public List<BuildingPaidView> getBuildingsPaid() {
        List<Object[]> rows = reportRepository.fetchBuildingsPaid();
        List<BuildingPaidView> result = new ArrayList<>();
        for (Object[] row : rows) {
            Building b = (Building) row[0];
            BigDecimal paid = (BigDecimal) row[1];
            result.add(new BuildingPaidView(b, paid));
        }
        return result;
    }

    public List<EmployeeBuildingsView> getEmployeesByName(Long companyId) {
        return getEmployeesWithBuildingCounts(companyId,
                "ORDER BY p.firstName, p.lastName, p.id");
    }

    public List<EmployeeBuildingsView> getEmployeesByBuildingCount(Long companyId) {
        return getEmployeesWithBuildingCounts(companyId,
                "ORDER BY COUNT(c) ASC, p.firstName, p.lastName, p.id");
    }

    public List<EmployeeDueView> getEmployeesDue(Long companyId) {
        List<Person> persons = reportRepository.findEmployeesByCompany(companyId);
        List<EmployeeDueView> result = new ArrayList<>();
        for (Person p : persons) {
            BigDecimal due = totalDueForEmployee(companyId, p.getId());
            result.add(new EmployeeDueView(p, due));
        }
        return result;
    }

    public List<EmployeePaidView> getEmployeesPaid(Long companyId) {
        List<Object[]> rows = reportRepository.fetchEmployeesPaid(companyId);
        List<EmployeePaidView> result = new ArrayList<>();
        for (Object[] row : rows) {
            Person p = (Person) row[0];
            BigDecimal paid = (BigDecimal) row[1];
            result.add(new EmployeePaidView(p, paid));
        }
        return result;
    }

    public List<CompanyEmployeesView> getCompaniesWithEmployees() {
        List<Object[]> rows = reportRepository.fetchCompaniesWithEmployees();
        Map<Long, String> companyNames = new HashMap<>();
        Map<Long, List<String>> employeesByCompany = new HashMap<>();
        for (Object[] row : rows) {
            Long companyId = (Long) row[0];
            String companyName = row[1] == null ? "" : row[1].toString();
            String firstName = row[2] == null ? "" : row[2].toString();
            String lastName = row[3] == null ? "" : row[3].toString();
            companyNames.put(companyId, companyName);
            if (!firstName.isEmpty() || !lastName.isEmpty()) {
                String fullName = (firstName + " " + lastName).trim();
                employeesByCompany.computeIfAbsent(companyId, k -> new ArrayList<>()).add(fullName);
            } else {
                employeesByCompany.computeIfAbsent(companyId, k -> new ArrayList<>());
            }
        }

        List<CompanyEmployeesView> result = new ArrayList<>();
        for (Map.Entry<Long, String> entry : companyNames.entrySet()) {
            Long companyId = entry.getKey();
            String companyName = entry.getValue();
            String employees = String.join(", ", employeesByCompany.getOrDefault(companyId, List.of()));
            result.add(new CompanyEmployeesView(companyId, companyName, employees));
        }
        result.sort((a, b) -> a.getCompanyName().compareToIgnoreCase(b.getCompanyName()));
        return result;
    }

    private List<EmployeeBuildingsView> getEmployeesWithBuildingCounts(Long companyId, String orderBy) {
        List<Object[]> rows = orderBy.contains("COUNT(c)")
                ? reportRepository.fetchEmployeesByBuildingCount(companyId)
                : reportRepository.fetchEmployeesByNameWithBuildingCounts(companyId);
        List<EmployeeBuildingsView> result = new ArrayList<>();
        for (Object[] row : rows) {
            Person p = (Person) row[0];
            Long count = (Long) row[1];
            result.add(new EmployeeBuildingsView(p, count == null ? 0 : count));
        }
        return result;
    }

    public List<BuildingEmployeeView> getBuildingsByEmployees(Long companyId) {
        List<Object[]> rows = reportRepository.fetchBuildingsByEmployees(companyId);
        List<BuildingEmployeeView> result = new ArrayList<>();
        for (Object[] row : rows) {
            Person p = (Person) row[0];
            Building b = (Building) row[1];
            result.add(new BuildingEmployeeView(p, b));
        }
        return result;
    }

    public List<ApartmentView> getApartmentsByBuilding(Long buildingId) {
        List<Apartment> apartments = reportRepository.findApartmentsByBuilding(buildingId);
        List<ApartmentView> result = new ArrayList<>();
        for (Apartment a : apartments) {
            result.add(new ApartmentView(a));
        }
        return result;
    }

    public List<ApartmentPeopleView> getApartmentsWithPeople() {
        List<Object[]> apartments = reportRepository.fetchApartmentsForPeople();
        List<Object[]> owners = reportRepository.fetchOwnersForPeople();
        List<Object[]> residents = reportRepository.fetchResidentsForPeople();

        Map<Long, List<String>> ownersMap = new HashMap<>();
        for (Object[] row : owners) {
            Long apartmentId = (Long) row[0];
            String name = (row[1] == null ? "" : row[1].toString())
                    + " "
                    + (row[2] == null ? "" : row[2].toString());
            ownersMap.computeIfAbsent(apartmentId, k -> new ArrayList<>()).add(name.trim());
        }

        Map<Long, List<String>> residentsMap = new HashMap<>();
        for (Object[] row : residents) {
            Long apartmentId = (Long) row[0];
            String name = (row[1] == null ? "" : row[1].toString())
                    + " "
                    + (row[2] == null ? "" : row[2].toString());
            residentsMap.computeIfAbsent(apartmentId, k -> new ArrayList<>()).add(name.trim());
        }

        List<ApartmentPeopleView> result = new ArrayList<>();
        for (Object[] row : apartments) {
            Long apartmentId = (Long) row[0];
            String number = row[1] == null ? "" : row[1].toString();
            String address = row[2] == null ? "" : row[2].toString();
            String label = number + " (" + address + ")";
            String ownersText = String.join(", ", ownersMap.getOrDefault(apartmentId, List.of()));
            String residentsText = String.join(", ", residentsMap.getOrDefault(apartmentId, List.of()));
            result.add(new ApartmentPeopleView(label, ownersText, residentsText));
        }
        return result;
    }

    public List<ResidentView> getResidentsByName(Long buildingId) {
        List<Person> persons = reportRepository.findResidentsByName(buildingId);
        List<ResidentView> result = new ArrayList<>();
        for (Person p : persons) {
            result.add(new ResidentView(p));
        }
        return result;
    }

    public List<ResidentView> getResidentsByAge(Long buildingId) {
        List<Person> persons = reportRepository.findResidentsByAge(buildingId);
        List<ResidentView> result = new ArrayList<>();
        for (Person p : persons) {
            result.add(new ResidentView(p));
        }
        return result;
    }

    private BigDecimal totalDueForCompany(Long companyId) {
        List<Contract> contracts = contractRepository.findByCompany(companyId);
        BigDecimal total = BigDecimal.ZERO;
        for (Contract c : contracts) {
            total = total.add(calculateDueForBuilding(c.getBuilding().getId()));
        }
        return total;
    }

    private BigDecimal totalDueForEmployee(Long companyId, Long employeeId) {
        List<Contract> contracts = contractRepository.findByCompanyAndEmployee(companyId, employeeId);
        BigDecimal total = BigDecimal.ZERO;
        for (Contract c : contracts) {
            total = total.add(calculateDueForBuilding(c.getBuilding().getId()));
        }
        return total;
    }

    private BigDecimal calculateDueForBuilding(Long buildingId) {
        Contract contract = contractRepository.findByBuilding(buildingId);
        if (contract == null) {
            return BigDecimal.ZERO;
        }
        Map<String, BigDecimal> feeMap = loadFeesByContract(contract.getId());

        BigDecimal pricePerSqm = feeMap.getOrDefault(ContractService.FEE_PRICE_PER_SQM, BigDecimal.ZERO);
        BigDecimal liftFee = feeMap.getOrDefault(ContractService.FEE_LIFT, BigDecimal.ZERO);
        BigDecimal petFee = feeMap.getOrDefault(ContractService.FEE_PET, BigDecimal.ZERO);

        double totalArea = reportRepository.sumApartmentAreas(buildingId);
        int totalPets = reportRepository.sumApartmentPets(buildingId);
        long liftResidents = countLiftResidentsOver7(buildingId);

        BigDecimal base = pricePerSqm.multiply(BigDecimal.valueOf(totalArea));
        BigDecimal lift = liftFee.multiply(BigDecimal.valueOf(liftResidents));
        BigDecimal pets = petFee.multiply(BigDecimal.valueOf(totalPets));

        return base.add(lift).add(pets);
    }

    private Map<String, BigDecimal> loadFeesByContract(Long contractId) {
        List<ContractsFee> fees = contractsFeeRepository.findByContractId(contractId);
        Map<String, BigDecimal> map = new HashMap<>();
        for (ContractsFee cf : fees) {
            if (cf.getFeeType() != null && cf.getFeeType().getName() != null) {
                map.put(cf.getFeeType().getName(), cf.getAmount());
            }
        }
        return map;
    }

    private long countLiftResidentsOver7(Long buildingId) {
        List<ApartmentResident> residents = reportRepository.findResidentsByBuilding(buildingId);
        LocalDate cutoff = LocalDate.now().minusYears(7);
        return residents.stream()
                .filter(ApartmentResident::isLiftUsed)
                .filter(ar -> ar.getPerson() != null && ar.getPerson().getBirthDate() != null)
                .filter(ar -> !ar.getPerson().getBirthDate().isAfter(cutoff))
                .count();
    }
}
