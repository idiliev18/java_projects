package org.example.service;

import org.example.dto.ApartmentOwnerUpdateRequest;
import org.example.entity.ApartmentOwner;

import java.util.List;

public interface IApartmentOwnerService {
    ApartmentOwner addOwnerToApartment(Long apartmentId, Long personId);

    ApartmentOwner updateOwnerLink(Long id, ApartmentOwnerUpdateRequest request);

    void removeOwnerLink(Long id);

    ApartmentOwner getOwnerLink(Long id);

    List<ApartmentOwner> getAllOwnerLinks();
}
