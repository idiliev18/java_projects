package org.example.service;

import org.example.dto.CompanyEmployeeUpdateRequest;
import org.example.entity.Company;
import org.example.entity.CompanyEmployee;
import org.example.entity.Person;
import org.example.repository.ICompanyEmployeeRepository;
import org.example.repository.ICompanyRepository;
import org.example.repository.IPersonRepository;
import org.example.repository.CompanyEmployeeRepository;
import org.example.repository.CompanyRepository;
import org.example.repository.PersonRepository;

import java.util.List;

public class CompanyEmployeeService implements ICompanyEmployeeService {
    private final ICompanyEmployeeRepository companyEmployeeRepository = new CompanyEmployeeRepository();
    private final ICompanyRepository companyRepository = new CompanyRepository();
    private final IPersonRepository personRepository = new PersonRepository();

    public CompanyEmployee addEmployeeToCompany(Long companyId, Long personId) {
        Company company = companyRepository.findById(companyId);
        if (company == null) {
            throw new IllegalArgumentException("Company not found: id=" + companyId);
        }
        Person person = personRepository.findById(personId);
        if (person == null) {
            throw new IllegalArgumentException("Person not found: id=" + personId);
        }
        if (companyEmployeeRepository.existsByCompanyAndPerson(companyId, personId)) {
            throw new IllegalArgumentException("Employee already assigned to company: companyId="
                    + companyId + ", personId=" + personId);
        }
        CompanyEmployee link = new CompanyEmployee();
        link.setCompany(company);
        link.setPerson(person);
        return companyEmployeeRepository.save(link);
    }

    public CompanyEmployee updateEmployeeLink(Long id, CompanyEmployeeUpdateRequest request) {
        CompanyEmployee link = companyEmployeeRepository.findById(id);
        if (link == null) {
            throw new IllegalArgumentException("Company employee link not found: id=" + id);
        }
        if (request != null) {
            if (request.getCompanyId() != null) {
                Company company = companyRepository.findById(request.getCompanyId());
                if (company == null) {
                    throw new IllegalArgumentException("Company not found: id=" + request.getCompanyId());
                }
                link.setCompany(company);
            }
            if (request.getPersonId() != null) {
                Person person = personRepository.findById(request.getPersonId());
                if (person == null) {
                    throw new IllegalArgumentException("Person not found: id=" + request.getPersonId());
                }
                link.setPerson(person);
            }
        }
        Long companyId = link.getCompany() == null ? null : link.getCompany().getId();
        Long personId = link.getPerson() == null ? null : link.getPerson().getId();
        if (companyId != null && personId != null
                && companyEmployeeRepository.existsByCompanyAndPersonExcludingId(companyId, personId, link.getId())) {
            throw new IllegalArgumentException("Employee already assigned to company: companyId="
                    + companyId + ", personId=" + personId);
        }
        return companyEmployeeRepository.update(link);
    }

    public void removeEmployeeLink(Long id) {
        companyEmployeeRepository.deleteById(id);
    }

    public CompanyEmployee getEmployeeLink(Long id) {
        return companyEmployeeRepository.findById(id);
    }

    public List<CompanyEmployee> getAllEmployeeLinks() {
        return companyEmployeeRepository.findAll();
    }
}
