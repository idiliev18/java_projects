package org.example.service;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import org.example.dto.CompanyUpdateRequest;
import org.example.entity.Company;
import org.example.repository.ICompanyRepository;
import org.example.repository.CompanyRepository;

import java.util.List;
import java.util.Set;

public class CompanyService implements ICompanyService {
    private final ICompanyRepository companyRepository = new CompanyRepository();
    private final Validator validator;

    public CompanyService() {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        this.validator = factory.getValidator();
    }

    public Company createCompany(String name) {
        Company company = new Company();
        company.setName(name);
        validate(company);
        return companyRepository.save(company);
    }

    public Company updateCompany(Long id, CompanyUpdateRequest request) {
        Company company = companyRepository.findById(id);
        if (company == null) {
            throw new IllegalArgumentException("Company not found: id=" + id);
        }
        if (request != null && request.getName() != null) {
            company.setName(request.getName());
        }
        validate(company);
        return companyRepository.update(company);
    }

    public void deleteCompany(Long id) {
        companyRepository.deleteById(id);
    }

    public Company getCompany(Long id) {
        return companyRepository.findById(id);
    }

    public List<Company> getAllCompanies() {
        return companyRepository.findAll();
    }

    private void validate(Company company) {
        Set<ConstraintViolation<Company>> violations = validator.validate(company);
        if (!violations.isEmpty()) {
            StringBuilder sb = new StringBuilder("Validation failed: ");
            for (ConstraintViolation<Company> v : violations) {
                sb.append(v.getPropertyPath()).append(" ").append(v.getMessage()).append("; ");
            }
            throw new IllegalArgumentException(sb.toString());
        }
    }
}
