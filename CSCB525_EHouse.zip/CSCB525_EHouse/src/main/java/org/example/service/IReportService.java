package org.example.service;

import org.example.view.ApartmentPeopleView;
import org.example.view.ApartmentView;
import org.example.view.BuildingDueView;
import org.example.view.BuildingEmployeeView;
import org.example.view.BuildingPaidView;
import org.example.view.CompanyDueView;
import org.example.view.CompanyEmployeesView;
import org.example.view.CompanyRevenueView;
import org.example.view.EmployeeBuildingsView;
import org.example.view.EmployeeDueView;
import org.example.view.EmployeePaidView;
import org.example.view.ResidentView;

import java.util.List;

public interface IReportService {
    List<CompanyRevenueView> getCompaniesByRevenue();

    List<CompanyDueView> getCompaniesDue();

    List<BuildingDueView> getBuildingsDue();

    List<BuildingPaidView> getBuildingsPaid();

    List<EmployeeBuildingsView> getEmployeesByName(Long companyId);

    List<EmployeeBuildingsView> getEmployeesByBuildingCount(Long companyId);

    List<EmployeeDueView> getEmployeesDue(Long companyId);

    List<EmployeePaidView> getEmployeesPaid(Long companyId);

    List<CompanyEmployeesView> getCompaniesWithEmployees();

    List<BuildingEmployeeView> getBuildingsByEmployees(Long companyId);

    List<ApartmentView> getApartmentsByBuilding(Long buildingId);

    List<ApartmentPeopleView> getApartmentsWithPeople();

    List<ResidentView> getResidentsByName(Long buildingId);

    List<ResidentView> getResidentsByAge(Long buildingId);
}
