package org.example.service;

import org.example.dto.CompanyUpdateRequest;
import org.example.entity.Company;

import java.util.List;

public interface ICompanyService {
    Company createCompany(String name);

    Company updateCompany(Long id, CompanyUpdateRequest request);

    void deleteCompany(Long id);

    Company getCompany(Long id);

    List<Company> getAllCompanies();
}
