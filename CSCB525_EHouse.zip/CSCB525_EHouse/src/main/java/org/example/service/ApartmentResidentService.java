package org.example.service;

import org.example.dto.ApartmentResidentUpdateRequest;
import org.example.entity.Apartment;
import org.example.entity.ApartmentResident;
import org.example.entity.Person;
import org.example.repository.IApartmentRepository;
import org.example.repository.IApartmentResidentRepository;
import org.example.repository.IPersonRepository;
import org.example.repository.ApartmentRepository;
import org.example.repository.ApartmentResidentRepository;
import org.example.repository.PersonRepository;

import java.util.List;

public class ApartmentResidentService implements IApartmentResidentService {
    private final IApartmentResidentRepository residentRepository = new ApartmentResidentRepository();
    private final IApartmentRepository apartmentRepository = new ApartmentRepository();
    private final IPersonRepository personRepository = new PersonRepository();

    public ApartmentResident addResidentToApartment(Long apartmentId, Long personId, boolean isLiftUsed) {
        Apartment apartment = apartmentRepository.findById(apartmentId);
        if (apartment == null) {
            throw new IllegalArgumentException("Apartment not found: id=" + apartmentId);
        }
        Person person = personRepository.findById(personId);
        if (person == null) {
            throw new IllegalArgumentException("Person not found: id=" + personId);
        }
        if (residentRepository.existsByApartmentAndPerson(apartmentId, personId)) {
            throw new IllegalArgumentException("Resident already linked to apartment: apartmentId="
                    + apartmentId + ", personId=" + personId);
        }
        ApartmentResident link = new ApartmentResident();
        link.setApartment(apartment);
        link.setPerson(person);
        link.setLiftUsed(isLiftUsed);
        return residentRepository.save(link);
    }

    public ApartmentResident updateResidentLink(Long id, ApartmentResidentUpdateRequest request) {
        ApartmentResident link = residentRepository.findById(id);
        if (link == null) {
            throw new IllegalArgumentException("Resident link not found: id=" + id);
        }
        if (request != null) {
            if (request.getApartmentId() != null) {
                Apartment apartment = apartmentRepository.findById(request.getApartmentId());
                if (apartment == null) {
                    throw new IllegalArgumentException("Apartment not found: id=" + request.getApartmentId());
                }
                link.setApartment(apartment);
            }
            if (request.getPersonId() != null) {
                Person person = personRepository.findById(request.getPersonId());
                if (person == null) {
                    throw new IllegalArgumentException("Person not found: id=" + request.getPersonId());
                }
                link.setPerson(person);
            }
            if (request.getLiftUsed() != null) {
                link.setLiftUsed(request.getLiftUsed());
            }
        }
        Long apartmentId = link.getApartment() == null ? null : link.getApartment().getId();
        Long personId = link.getPerson() == null ? null : link.getPerson().getId();
        if (apartmentId != null && personId != null
                && residentRepository.existsByApartmentAndPersonExcludingId(apartmentId, personId, link.getId())) {
            throw new IllegalArgumentException("Resident already linked to apartment: apartmentId="
                    + apartmentId + ", personId=" + personId);
        }
        return residentRepository.update(link);
    }

    public void removeResidentLink(Long id) {
        residentRepository.deleteById(id);
    }

    public ApartmentResident getResidentLink(Long id) {
        return residentRepository.findById(id);
    }

    public List<ApartmentResident> getAllResidentLinks() {
        return residentRepository.findAll();
    }
}
