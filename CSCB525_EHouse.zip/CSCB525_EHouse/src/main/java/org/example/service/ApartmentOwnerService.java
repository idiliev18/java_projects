package org.example.service;

import org.example.dto.ApartmentOwnerUpdateRequest;
import org.example.entity.Apartment;
import org.example.entity.ApartmentOwner;
import org.example.entity.Person;
import org.example.repository.IApartmentOwnerRepository;
import org.example.repository.IApartmentRepository;
import org.example.repository.IPersonRepository;
import org.example.repository.ApartmentOwnerRepository;
import org.example.repository.ApartmentRepository;
import org.example.repository.PersonRepository;

import java.util.List;

public class ApartmentOwnerService implements IApartmentOwnerService {
    private final IApartmentOwnerRepository ownerRepository = new ApartmentOwnerRepository();
    private final IApartmentRepository apartmentRepository = new ApartmentRepository();
    private final IPersonRepository personRepository = new PersonRepository();

    public ApartmentOwner addOwnerToApartment(Long apartmentId, Long personId) {
        Apartment apartment = apartmentRepository.findById(apartmentId);
        if (apartment == null) {
            throw new IllegalArgumentException("Apartment not found: id=" + apartmentId);
        }
        Person person = personRepository.findById(personId);
        if (person == null) {
            throw new IllegalArgumentException("Person not found: id=" + personId);
        }
        if (ownerRepository.existsByApartmentAndPerson(apartmentId, personId)) {
            throw new IllegalArgumentException("Owner already linked to apartment: apartmentId="
                    + apartmentId + ", personId=" + personId);
        }
        ApartmentOwner link = new ApartmentOwner();
        link.setApartment(apartment);
        link.setPerson(person);
        return ownerRepository.save(link);
    }

    public ApartmentOwner updateOwnerLink(Long id, ApartmentOwnerUpdateRequest request) {
        ApartmentOwner link = ownerRepository.findById(id);
        if (link == null) {
            throw new IllegalArgumentException("Owner link not found: id=" + id);
        }
        if (request != null) {
            if (request.getApartmentId() != null) {
                Apartment apartment = apartmentRepository.findById(request.getApartmentId());
                if (apartment == null) {
                    throw new IllegalArgumentException("Apartment not found: id=" + request.getApartmentId());
                }
                link.setApartment(apartment);
            }
            if (request.getPersonId() != null) {
                Person person = personRepository.findById(request.getPersonId());
                if (person == null) {
                    throw new IllegalArgumentException("Person not found: id=" + request.getPersonId());
                }
                link.setPerson(person);
            }
        }
        Long apartmentId = link.getApartment() == null ? null : link.getApartment().getId();
        Long personId = link.getPerson() == null ? null : link.getPerson().getId();
        if (apartmentId != null && personId != null
                && ownerRepository.existsByApartmentAndPersonExcludingId(apartmentId, personId, link.getId())) {
            throw new IllegalArgumentException("Owner already linked to apartment: apartmentId="
                    + apartmentId + ", personId=" + personId);
        }
        return ownerRepository.update(link);
    }

    public void removeOwnerLink(Long id) {
        ownerRepository.deleteById(id);
    }

    public ApartmentOwner getOwnerLink(Long id) {
        return ownerRepository.findById(id);
    }

    public List<ApartmentOwner> getAllOwnerLinks() {
        return ownerRepository.findAll();
    }
}
