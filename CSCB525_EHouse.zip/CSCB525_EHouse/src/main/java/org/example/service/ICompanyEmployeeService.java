package org.example.service;

import org.example.dto.CompanyEmployeeUpdateRequest;
import org.example.entity.CompanyEmployee;

import java.util.List;

public interface ICompanyEmployeeService {
    CompanyEmployee addEmployeeToCompany(Long companyId, Long personId);

    CompanyEmployee updateEmployeeLink(Long id, CompanyEmployeeUpdateRequest request);

    void removeEmployeeLink(Long id);

    CompanyEmployee getEmployeeLink(Long id);

    List<CompanyEmployee> getAllEmployeeLinks();
}
