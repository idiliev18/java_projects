package org.example.service;

import org.example.dto.ApartmentUpdateRequest;
import org.example.entity.Apartment;

import java.util.List;

public interface IApartmentService {
    Apartment createApartment(Long buildingId, String number, int floor, double area, int petCount);

    Apartment updateApartment(Long id, ApartmentUpdateRequest request);

    Apartment getApartment(Long id);

    List<Apartment> getAllApartments();
}
