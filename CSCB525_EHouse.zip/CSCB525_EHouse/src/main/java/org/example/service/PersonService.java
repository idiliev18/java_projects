package org.example.service;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import org.example.dto.PersonUpdateRequest;
import org.example.entity.Person;
import org.example.repository.IPersonRepository;
import org.example.repository.PersonRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

public class PersonService implements IPersonService {
    private final IPersonRepository personRepository = new PersonRepository();
    private final Validator validator;

    public PersonService() {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        this.validator = factory.getValidator();
    }

    public Person createPerson(String firstName, String lastName, LocalDate birthDate, String email) {
        Person person = new Person();
        person.setFirstName(firstName);
        person.setLastName(lastName);
        person.setBirthDate(birthDate);
        person.setEmail(email);
        validate(person);
        return personRepository.save(person);
    }

    public Person updatePerson(Long id, PersonUpdateRequest request) {
        Person person = personRepository.findById(id);
        if (person == null) {
            throw new IllegalArgumentException("Person not found: id=" + id);
        }
        if (request != null) {
            if (request.getFirstName() != null) {
                person.setFirstName(request.getFirstName());
            }
            if (request.getLastName() != null) {
                person.setLastName(request.getLastName());
            }
            if (request.getBirthDate() != null) {
                person.setBirthDate(request.getBirthDate());
            }
            if (request.getEmail() != null) {
                person.setEmail(request.getEmail());
            }
        }
        validate(person);
        return personRepository.update(person);
    }

    public void deletePerson(Long id) {
        personRepository.deleteById(id);
    }

    public Person getPerson(Long id) {
        return personRepository.findById(id);
    }

    public List<Person> getAllPersons() {
        return personRepository.findAll();
    }

    private void validate(Person person) {
        Set<ConstraintViolation<Person>> violations = validator.validate(person);
        if (!violations.isEmpty()) {
            StringBuilder sb = new StringBuilder("Validation failed: ");
            for (ConstraintViolation<Person> v : violations) {
                sb.append(v.getPropertyPath()).append(" ").append(v.getMessage()).append("; ");
            }
            throw new IllegalArgumentException(sb.toString());
        }
    }
}
