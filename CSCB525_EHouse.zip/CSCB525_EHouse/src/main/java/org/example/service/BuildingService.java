package org.example.service;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import org.example.dto.BuildingUpdateRequest;
import org.example.entity.Building;
import org.example.repository.IBuildingRepository;
import org.example.repository.BuildingRepository;

import java.util.List;
import java.util.Set;

public class BuildingService implements IBuildingService {
    private final IBuildingRepository buildingRepository = new BuildingRepository();
    private final Validator validator;

    public BuildingService() {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        this.validator = factory.getValidator();
    }

    public Building createBuilding(String address, int floors, double buildArea, double sharedArea) {
        Building building = new Building();
        building.setAddress(address);
        building.setFloors(floors);
        building.setBuildArea(buildArea);
        building.setSharedArea(sharedArea);
        validate(building);
        return buildingRepository.save(building);
    }

    public Building updateBuilding(Long id, BuildingUpdateRequest request) {
        Building building = buildingRepository.findById(id);
        if (building == null) {
            throw new IllegalArgumentException("Building not found: id=" + id);
        }
        if (request != null) {
            if (request.getAddress() != null) {
                building.setAddress(request.getAddress());
            }
            if (request.getFloors() != null) {
                building.setFloors(request.getFloors());
            }
            if (request.getBuildArea() != null) {
                building.setBuildArea(request.getBuildArea());
            }
            if (request.getSharedArea() != null) {
                building.setSharedArea(request.getSharedArea());
            }
        }
        validate(building);
        return buildingRepository.update(building);
    }

    public void deleteBuilding(Long id) {
        buildingRepository.deleteById(id);
    }

    public Building getBuilding(Long id) {
        return buildingRepository.findById(id);
    }

    public List<Building> getAllBuildings() {
        return buildingRepository.findAll();
    }

    private void validate(Building building) {
        Set<ConstraintViolation<Building>> violations = validator.validate(building);
        if (!violations.isEmpty()) {
            StringBuilder sb = new StringBuilder("Validation failed: ");
            for (ConstraintViolation<Building> v : violations) {
                sb.append(v.getPropertyPath()).append(" ").append(v.getMessage()).append("; ");
            }
            throw new IllegalArgumentException(sb.toString());
        }
    }
}
