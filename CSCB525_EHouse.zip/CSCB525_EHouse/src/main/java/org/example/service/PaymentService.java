package org.example.service;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.example.entity.Apartment;
import org.example.entity.ApartmentResident;
import org.example.entity.Contract;
import org.example.entity.ContractsFee;
import org.example.entity.Payment;
import org.example.report.PaymentReportRow;
import org.example.repository.IApartmentRepository;
import org.example.repository.IContractRepository;
import org.example.repository.IContractsFeeRepository;
import org.example.repository.IPaymentRepository;
import org.example.repository.ApartmentRepository;
import org.example.repository.ContractRepository;
import org.example.repository.ContractsFeeRepository;
import org.example.repository.PaymentRepository;
import org.example.util.JpaUtil;
import org.example.utils.PaymentReportGenerator;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PaymentService implements IPaymentService {
    private final IPaymentRepository paymentRepository = new PaymentRepository();
    private final IApartmentRepository apartmentRepository = new ApartmentRepository();
    private final IContractRepository contractRepository = new ContractRepository();
    private final IContractsFeeRepository contractsFeeRepository = new ContractsFeeRepository();
    private final PaymentReportGenerator paymentReportGenerator = new PaymentReportGenerator();

    private static final Path DEFAULT_PAYMENT_REPORT = Path.of("reports", "payments_by_company.pdf");
    private static final DateTimeFormatter PAYMENT_DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    private static final int MONEY_SCALE = 2;
    private static final RoundingMode MONEY_ROUNDING = RoundingMode.HALF_UP;

    public Payment payApartment(Long apartmentId, BigDecimal amount, LocalDateTime paymentDate) {
        return payApartment(apartmentId, amount, paymentDate, DEFAULT_PAYMENT_REPORT);
    }

    public Payment payApartment(Long apartmentId, BigDecimal amount, LocalDateTime paymentDate, Path filePath) {
        if (amount == null || paymentDate == null) {
            throw new IllegalArgumentException("Amount and payment date are required.");
        }
        Apartment apartment = apartmentRepository.findById(apartmentId);
        if (apartment == null) {
            throw new IllegalArgumentException("Apartment not found: id=" + apartmentId);
        }

        Contract contract = contractRepository.findByBuilding(apartment.getBuilding().getId());
        if (contract == null) {
            throw new IllegalArgumentException("No contract for building id=" + apartment.getBuilding().getId());
        }

        BigDecimal due = calculateDueForApartment(apartment, contract, paymentDate.toLocalDate());
        BigDecimal normalizedDue = normalizeMoney(due);
        BigDecimal normalizedAmount = normalizeMoney(amount);
        if (normalizedAmount.compareTo(normalizedDue) != 0) {
            throw new IllegalArgumentException("Payment must be full. Due=" + normalizedDue + ", paid=" + normalizedAmount);
        }

        Payment payment = new Payment();
        payment.setApartment(apartment);
        payment.setAmount(normalizedAmount);
        payment.setPaymentDate(paymentDate);
        Payment saved = paymentRepository.save(payment);

        generatePaymentReport(filePath);

        return saved;
    }

    public BigDecimal calculateDueForApartment(Long apartmentId) {
        Apartment apartment = apartmentRepository.findById(apartmentId);
        if (apartment == null) {
            throw new IllegalArgumentException("Apartment not found: id=" + apartmentId);
        }
        Contract contract = contractRepository.findByBuilding(apartment.getBuilding().getId());
        if (contract == null) {
            throw new IllegalArgumentException("No contract for building id=" + apartment.getBuilding().getId());
        }
        return calculateDueForApartment(apartment, contract, LocalDate.now());
    }

    private BigDecimal calculateDueForApartment(Apartment apartment, Contract contract, LocalDate referenceDate) {
        if (apartment.getBuilding() == null || apartment.getBuilding().getId() == null) {
            throw new IllegalArgumentException("Apartment has no building.");
        }

        Map<String, BigDecimal> feeMap = loadFeesByContract(contract.getId());
        BigDecimal pricePerSqm = feeMap.getOrDefault(ContractService.FEE_PRICE_PER_SQM, BigDecimal.ZERO);
        BigDecimal liftFee = feeMap.getOrDefault(ContractService.FEE_LIFT, BigDecimal.ZERO);
        BigDecimal petFee = feeMap.getOrDefault(ContractService.FEE_PET, BigDecimal.ZERO);

        BigDecimal base = pricePerSqm.multiply(BigDecimal.valueOf(apartment.getArea()));
        long liftResidents = countLiftResidentsOver7(apartment.getId(), referenceDate);
        BigDecimal lift = liftFee.multiply(BigDecimal.valueOf(liftResidents));
        BigDecimal pets = petFee.multiply(BigDecimal.valueOf(apartment.getPetCount()));

        return normalizeMoney(base.add(lift).add(pets));
    }

    private Map<String, BigDecimal> loadFeesByContract(Long contractId) {
        List<ContractsFee> fees = contractsFeeRepository.findByContractId(contractId);
        Map<String, BigDecimal> map = new HashMap<>();
        for (ContractsFee cf : fees) {
            if (cf.getFeeType() != null && cf.getFeeType().getName() != null) {
                map.put(cf.getFeeType().getName(), cf.getAmount());
            }
        }
        return map;
    }

    private long countLiftResidentsOver7(Long apartmentId, LocalDate referenceDate) {
        List<ApartmentResident> residents = loadResidentsByApartment(apartmentId);
        LocalDate cutoff = (referenceDate == null ? LocalDate.now() : referenceDate).minusYears(7);
        return residents.stream()
                .filter(ApartmentResident::isLiftUsed)
                .filter(ar -> ar.getPerson() != null && ar.getPerson().getBirthDate() != null)
                .filter(ar -> !ar.getPerson().getBirthDate().isAfter(cutoff))
                .count();
    }

    private List<ApartmentResident> loadResidentsByApartment(Long apartmentId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<ApartmentResident> query = em.createQuery(
                    "SELECT ar FROM ApartmentResident ar WHERE ar.apartment.id = :apartmentId",
                    ApartmentResident.class);
            query.setParameter("apartmentId", apartmentId);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    private String buildEmployeeName(org.example.entity.Person person) {
        if (person == null) {
            return "";
        }
        String fn = person.getFirstName() == null ? "" : person.getFirstName();
        String ln = person.getLastName() == null ? "" : person.getLastName();
        return (fn + " " + ln).trim();
    }

    private void generatePaymentReport(Path filePath) {
        List<Payment> payments = paymentRepository.findAll();
        List<PaymentReportRow> rows = new ArrayList<>(payments.size());
        Map<Long, Contract> contractCache = new HashMap<>();
        Map<Long, BigDecimal> companyTotals = new HashMap<>();

        for (Payment payment : payments) {
            Apartment apartment = payment.getApartment();
            Long buildingId = apartment != null && apartment.getBuilding() != null
                    ? apartment.getBuilding().getId()
                    : null;
            Contract contract = null;
            if (buildingId != null) {
                contract = contractCache.computeIfAbsent(buildingId, contractRepository::findByBuilding);
            }
            Long companyId = contract != null && contract.getCompany() != null
                    ? contract.getCompany().getId()
                    : null;
            String companyName = contract != null && contract.getCompany() != null
                    ? contract.getCompany().getName()
                    : "";
            String employeeName = contract != null
                    ? buildEmployeeName(contract.getEmployee())
                    : "";
            String buildingAddress = apartment != null && apartment.getBuilding() != null
                    ? apartment.getBuilding().getAddress()
                    : "";
            String apartmentNumber = apartment != null ? apartment.getNumber() : "";
            String paidAt = payment.getPaymentDate() == null
                    ? ""
                    : payment.getPaymentDate().format(PAYMENT_DATE_FORMAT);

            rows.add(new PaymentReportRow(
                    companyId,
                    companyName,
                    employeeName,
                    buildingAddress,
                    apartmentNumber,
                    payment.getAmount(),
                    paidAt
            ));

            if (companyId != null && payment.getAmount() != null) {
                companyTotals.merge(companyId, payment.getAmount(), BigDecimal::add);
            }
        }

        rows.sort(Comparator.<PaymentReportRow, BigDecimal>comparing(
                        row -> companyTotals.getOrDefault(row.getCompanyId(), BigDecimal.ZERO))
                .reversed()
                .thenComparing(PaymentReportRow::getCompanyName, Comparator.nullsLast(String::compareTo))
                .thenComparing(PaymentReportRow::getPaymentDate, Comparator.nullsLast(String::compareTo)));

        paymentReportGenerator.generate(filePath, rows, LocalDateTime.now());
    }

    private BigDecimal normalizeMoney(BigDecimal value) {
        if (value == null) {
            return BigDecimal.ZERO.setScale(MONEY_SCALE, MONEY_ROUNDING);
        }
        return value.setScale(MONEY_SCALE, MONEY_ROUNDING);
    }
}
