package org.example.service;

import org.example.dto.ContractFeesUpdateRequest;
import org.example.entity.Contract;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public interface IContractService {
    Contract createContract(Long companyId, Long buildingId, int paymentDay, Map<String, BigDecimal> fees);

    List<Contract> reassignContractsForEmployee(Long companyId, Long leavingEmployeeId);

    void updateFeesForBuilding(Long companyId, Long buildingId, ContractFeesUpdateRequest request);
}
