package org.example.service;

import org.example.dto.BuildingUpdateRequest;
import org.example.entity.Building;

import java.util.List;

public interface IBuildingService {
    Building createBuilding(String address, int floors, double buildArea, double sharedArea);

    Building updateBuilding(Long id, BuildingUpdateRequest request);

    void deleteBuilding(Long id);

    Building getBuilding(Long id);

    List<Building> getAllBuildings();
}
