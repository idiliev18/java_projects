package org.example.service;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.example.dto.ContractFeesUpdateRequest;
import org.example.entity.Apartment;
import org.example.entity.ApartmentResident;
import org.example.entity.Company;
import org.example.entity.CompanyEmployee;
import org.example.entity.Contract;
import org.example.entity.ContractsFee;
import org.example.entity.FeeType;
import org.example.entity.Person;
import org.example.repository.ICompanyEmployeeRepository;
import org.example.repository.ICompanyRepository;
import org.example.repository.IBuildingRepository;
import org.example.repository.IContractRepository;
import org.example.repository.IContractsFeeRepository;
import org.example.repository.IFeeTypeRepository;
import org.example.repository.CompanyEmployeeRepository;
import org.example.repository.CompanyRepository;
import org.example.repository.BuildingRepository;
import org.example.repository.ContractRepository;
import org.example.repository.ContractsFeeRepository;
import org.example.repository.FeeTypeRepository;
import org.example.util.JpaUtil;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ContractService implements IContractService {
    public static final String FEE_PRICE_PER_SQM = "PRICE_PER_SQM";
    public static final String FEE_LIFT = "LIFT_FEE";
    public static final String FEE_PET = "PET_FEE";

    private final ICompanyRepository companyRepository = new CompanyRepository();
    private final IBuildingRepository buildingRepository = new BuildingRepository();
    private final ICompanyEmployeeRepository companyEmployeeRepository = new CompanyEmployeeRepository();
    private final IContractRepository contractRepository = new ContractRepository();
    private final IFeeTypeRepository feeTypeRepository = new FeeTypeRepository();
    private final IContractsFeeRepository contractsFeeRepository = new ContractsFeeRepository();

    public Contract createContract(Long companyId, Long buildingId, int paymentDay, Map<String, BigDecimal> fees) {
        if (fees == null || fees.isEmpty()) {
            throw new IllegalArgumentException("Fees are required for contract.");
        }
        if (paymentDay < 1 || paymentDay > 31) {
            throw new IllegalArgumentException("Payment day must be between 1 and 31.");
        }
        Company company = companyRepository.findById(companyId);
        if (company == null) {
            throw new IllegalArgumentException("Company not found: id=" + companyId);
        }
        org.example.entity.Building building = buildingRepository.findById(buildingId);
        if (building == null) {
            throw new IllegalArgumentException("Building not found: id=" + buildingId);
        }

        Contract existingByBuilding = contractRepository.findByBuilding(buildingId);
        if (existingByBuilding != null) {
            throw new IllegalArgumentException("Contract already exists for building id=" + buildingId);
        }

        Contract existing = contractRepository.findByCompanyAndBuilding(companyId, buildingId);
        if (existing != null) {
            throw new IllegalArgumentException("Contract already exists for company/building.");
        }

        Person employee = selectEmployee(companyId);

        EntityManager em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();

            Contract contract = new Contract();
            contract.setCompany(em.getReference(Company.class, companyId));
            contract.setBuilding(em.getReference(org.example.entity.Building.class, buildingId));
            contract.setEmployee(em.getReference(Person.class, employee.getId()));
            contract.setPaymentDay(paymentDay);
            em.persist(contract);

            for (Map.Entry<String, BigDecimal> entry : fees.entrySet()) {
                FeeType feeType = getOrCreateFeeType(entry.getKey());
                ContractsFee cf = new ContractsFee();
                cf.setContract(contract);
                cf.setFeeType(em.getReference(FeeType.class, feeType.getId()));
                cf.setAmount(entry.getValue());
                em.persist(cf);
            }

            em.getTransaction().commit();
            return contract;
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }

    public List<Contract> reassignContractsForEmployee(Long companyId, Long leavingEmployeeId) {
        List<Contract> contracts = contractRepository.findByCompanyAndEmployee(companyId, leavingEmployeeId);
        if (contracts.isEmpty()) {
            return List.of();
        }

        List<CompanyEmployee> remainingEmployees = companyEmployeeRepository.findAll().stream()
                .filter(ce -> ce.getCompany().getId().equals(companyId))
                .filter(ce -> !ce.getPerson().getId().equals(leavingEmployeeId))
                .toList();
        if (remainingEmployees.isEmpty()) {
            throw new IllegalArgumentException("No remaining employees to reassign contracts.");
        }

        List<Contract> reassigned = new java.util.ArrayList<>();
        for (Contract c : contracts) {
            Person nextEmployee = selectEmployeeExcluding(companyId, leavingEmployeeId);
            c.setEmployee(nextEmployee);
            reassigned.add(contractRepository.update(c));
        }
        return reassigned;
    }

    public void updateFeesForBuilding(Long companyId, Long buildingId, ContractFeesUpdateRequest request) {
        if (request == null || request.getFees() == null || request.getFees().isEmpty()) {
            throw new IllegalArgumentException("Fees are required for update.");
        }
        Contract contract = contractRepository.findByCompanyAndBuilding(companyId, buildingId);
        if (contract == null) {
            throw new IllegalArgumentException("Contract not found for company/building.");
        }
        for (Map.Entry<String, BigDecimal> entry : request.getFees().entrySet()) {
            FeeType feeType = getOrCreateFeeType(entry.getKey());
            ContractsFee existing = contractsFeeRepository.findByContractAndFeeType(contract.getId(), feeType.getId());
            if (existing == null) {
                ContractsFee cf = new ContractsFee();
                cf.setContract(contract);
                cf.setFeeType(feeType);
                cf.setAmount(entry.getValue());
                contractsFeeRepository.save(cf);
            } else {
                existing.setAmount(entry.getValue());
                contractsFeeRepository.update(existing);
            }
        }
    }

    private Person selectEmployee(Long companyId) {
        return selectEmployeeExcluding(companyId, null);
    }

    private Person selectEmployeeExcluding(Long companyId, Long excludedEmployeeId) {
        List<CompanyEmployee> employees = companyEmployeeRepository.findAll().stream()
                .filter(ce -> ce.getCompany().getId().equals(companyId))
                .filter(ce -> !ce.getPerson().getId().equals(excludedEmployeeId))
                .toList();
        if (employees.isEmpty()) {
            throw new IllegalArgumentException("No employees for company id=" + companyId);
        }

        return employees.stream()
                .map(CompanyEmployee::getPerson)
                .min(Comparator.<Person>comparingLong(p -> countBuildingsForEmployee(companyId, p.getId()))
                        .thenComparing(p -> totalMonthlyFeesForEmployee(companyId, p.getId()))
                        .thenComparing(this::employeeNameKey))
                .orElseThrow();
    }

    private String employeeNameKey(Person p) {
        String fn = p.getFirstName() == null ? "" : p.getFirstName();
        String ln = p.getLastName() == null ? "" : p.getLastName();
        return (fn + " " + ln).trim().toLowerCase();
    }

    private long countBuildingsForEmployee(Long companyId, Long employeeId) {
        return contractRepository.findByCompanyAndEmployee(companyId, employeeId).size();
    }

    private BigDecimal totalMonthlyFeesForEmployee(Long companyId, Long employeeId) {
        List<Contract> contracts = contractRepository.findByCompanyAndEmployee(companyId, employeeId);
        BigDecimal total = BigDecimal.ZERO;
        for (Contract c : contracts) {
            total = total.add(calculateMonthlyFeesForBuilding(c.getId(), c.getBuilding().getId(), LocalDate.now()));
        }
        return total;
    }

    private BigDecimal calculateMonthlyFeesForBuilding(Long contractId, Long buildingId, LocalDate referenceDate) {
        Map<String, BigDecimal> feeMap = loadFeesByContract(contractId);

        BigDecimal pricePerSqm = feeMap.getOrDefault(FEE_PRICE_PER_SQM, BigDecimal.ZERO);
        BigDecimal liftFee = feeMap.getOrDefault(FEE_LIFT, BigDecimal.ZERO);
        BigDecimal petFee = feeMap.getOrDefault(FEE_PET, BigDecimal.ZERO);

        double totalArea = sumApartmentAreas(buildingId);
        int totalPets = sumApartmentPets(buildingId);
        long liftResidents = countLiftResidentsOver7(buildingId, referenceDate);

        BigDecimal base = pricePerSqm.multiply(BigDecimal.valueOf(totalArea));
        BigDecimal lift = liftFee.multiply(BigDecimal.valueOf(liftResidents));
        BigDecimal pets = petFee.multiply(BigDecimal.valueOf(totalPets));

        return base.add(lift).add(pets);
    }

    private Map<String, BigDecimal> loadFeesByContract(Long contractId) {
        List<ContractsFee> fees = contractsFeeRepository.findByContractId(contractId);
        Map<String, BigDecimal> map = new HashMap<>();
        for (ContractsFee cf : fees) {
            if (cf.getFeeType() != null && cf.getFeeType().getName() != null) {
                map.put(cf.getFeeType().getName(), cf.getAmount());
            }
        }
        return map;
    }

    private double sumApartmentAreas(Long buildingId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Double> query = em.createQuery(
                    "SELECT COALESCE(SUM(a.area), 0) FROM Apartment a WHERE a.building.id = :buildingId",
                    Double.class);
            query.setParameter("buildingId", buildingId);
            return query.getSingleResult();
        } finally {
            em.close();
        }
    }

    private int sumApartmentPets(Long buildingId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<Long> query = em.createQuery(
                    "SELECT COALESCE(SUM(a.petCount), 0) FROM Apartment a WHERE a.building.id = :buildingId",
                    Long.class);
            query.setParameter("buildingId", buildingId);
            Long result = query.getSingleResult();
            return result == null ? 0 : result.intValue();
        } finally {
            em.close();
        }
    }

    private long countLiftResidentsOver7(Long buildingId, LocalDate referenceDate) {
        List<ApartmentResident> residents = loadResidentsByBuilding(buildingId);
        LocalDate cutoff = (referenceDate == null ? LocalDate.now() : referenceDate).minusYears(7);
        return residents.stream()
                .filter(ApartmentResident::isLiftUsed)
                .filter(ar -> ar.getPerson() != null && ar.getPerson().getBirthDate() != null)
                .filter(ar -> !ar.getPerson().getBirthDate().isAfter(cutoff))
                .count();
    }

    private List<ApartmentResident> loadResidentsByBuilding(Long buildingId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            TypedQuery<ApartmentResident> query = em.createQuery(
                    "SELECT ar FROM ApartmentResident ar WHERE ar.apartment.building.id = :buildingId",
                    ApartmentResident.class);
            query.setParameter("buildingId", buildingId);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    private FeeType getOrCreateFeeType(String name) {
        FeeType existing = feeTypeRepository.findByName(name);
        if (existing != null) {
            return existing;
        }
        FeeType feeType = new FeeType();
        feeType.setName(name);
        return feeTypeRepository.save(feeType);
    }

    private org.example.entity.Building findBuilding(Long buildingId) {
        EntityManager em = JpaUtil.getEntityManager();
        try {
            org.example.entity.Building building = em.find(org.example.entity.Building.class, buildingId);
            if (building == null) {
                throw new IllegalArgumentException("Building not found: id=" + buildingId);
            }
            return building;
        } finally {
            em.close();
        }
    }
}
