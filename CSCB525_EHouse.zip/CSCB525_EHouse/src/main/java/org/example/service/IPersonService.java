package org.example.service;

import org.example.dto.PersonUpdateRequest;
import org.example.entity.Person;

import java.time.LocalDate;
import java.util.List;

public interface IPersonService {
    Person createPerson(String firstName, String lastName, LocalDate birthDate, String email);

    Person updatePerson(Long id, PersonUpdateRequest request);

    void deletePerson(Long id);

    Person getPerson(Long id);

    List<Person> getAllPersons();
}
