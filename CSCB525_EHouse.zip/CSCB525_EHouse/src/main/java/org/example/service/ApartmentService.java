package org.example.service;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import org.example.dto.ApartmentUpdateRequest;
import org.example.entity.Apartment;
import org.example.entity.Building;
import org.example.repository.IApartmentRepository;
import org.example.repository.IBuildingRepository;
import org.example.repository.ApartmentRepository;
import org.example.repository.BuildingRepository;

import java.util.List;
import java.util.Set;

public class ApartmentService implements IApartmentService {
    private final IApartmentRepository apartmentRepository = new ApartmentRepository();
    private final IBuildingRepository buildingRepository = new BuildingRepository();
    private final Validator validator;

    public ApartmentService() {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        this.validator = factory.getValidator();
    }

    public Apartment createApartment(Long buildingId, String number, int floor, double area, int petCount) {
        Building building = buildingRepository.findById(buildingId);
        if (building == null) {
            throw new IllegalArgumentException("Building not found: id=" + buildingId);
        }
        Apartment apartment = new Apartment();
        apartment.setBuilding(building);
        apartment.setNumber(number);
        apartment.setFloor(floor);
        apartment.setArea(area);
        apartment.setPetCount(petCount);
        validate(apartment);
        return apartmentRepository.save(apartment);
    }

    public Apartment updateApartment(Long id, ApartmentUpdateRequest request) {
        Apartment apartment = apartmentRepository.findById(id);
        if (apartment == null) {
            throw new IllegalArgumentException("Apartment not found: id=" + id);
        }
        if (request != null) {
            if (request.getNumber() != null) {
                apartment.setNumber(request.getNumber());
            }
            if (request.getFloor() != null) {
                apartment.setFloor(request.getFloor());
            }
            if (request.getArea() != null) {
                apartment.setArea(request.getArea());
            }
            if (request.getPetCount() != null) {
                apartment.setPetCount(request.getPetCount());
            }
            if (request.getBuildingId() != null) {
                Building building = buildingRepository.findById(request.getBuildingId());
                if (building == null) {
                    throw new IllegalArgumentException("Building not found: id=" + request.getBuildingId());
                }
                apartment.setBuilding(building);
            }
        }
        validate(apartment);
        return apartmentRepository.update(apartment);
    }

    public Apartment getApartment(Long id) {
        return apartmentRepository.findById(id);
    }

    public List<Apartment> getAllApartments() {
        return apartmentRepository.findAll();
    }

    private void validate(Apartment apartment) {
        Set<ConstraintViolation<Apartment>> violations = validator.validate(apartment);
        if (!violations.isEmpty()) {
            StringBuilder sb = new StringBuilder("Validation failed: ");
            for (ConstraintViolation<Apartment> v : violations) {
                sb.append(v.getPropertyPath()).append(" ").append(v.getMessage()).append("; ");
            }
            throw new IllegalArgumentException(sb.toString());
        }
    }
}
