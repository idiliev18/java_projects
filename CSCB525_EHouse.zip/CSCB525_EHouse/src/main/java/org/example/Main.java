package org.example;

import org.example.dto.ApartmentOwnerUpdateRequest;
import org.example.dto.ApartmentResidentUpdateRequest;
import org.example.dto.BuildingUpdateRequest;
import org.example.dto.CompanyEmployeeUpdateRequest;
import org.example.dto.CompanyUpdateRequest;
import org.example.dto.PersonUpdateRequest;
import org.example.entity.Apartment;
import org.example.entity.ApartmentOwner;
import org.example.entity.ApartmentResident;
import org.example.entity.Building;
import org.example.entity.Company;
import org.example.entity.CompanyEmployee;
import org.example.entity.Contract;
import org.example.entity.Payment;
import org.example.entity.Person;
import org.example.repository.ContractsFeeRepository;
import org.example.repository.ContractRepository;
import org.example.service.IApartmentOwnerService;
import org.example.service.IApartmentResidentService;
import org.example.service.IApartmentService;
import org.example.service.IBuildingService;
import org.example.service.ICompanyEmployeeService;
import org.example.service.ICompanyService;
import org.example.service.IContractService;
import org.example.service.IPaymentService;
import org.example.service.IPersonService;
import org.example.service.IReportService;
import org.example.service.ApartmentOwnerService;
import org.example.service.ApartmentResidentService;
import org.example.service.ApartmentService;
import org.example.service.BuildingService;
import org.example.service.CompanyEmployeeService;
import org.example.service.CompanyService;
import org.example.service.ContractService;
import org.example.service.PaymentService;
import org.example.service.PersonService;
import org.example.service.ReportService;
import org.example.util.JpaUtil;
import org.example.utils.table.TableRenderer;
import org.example.view.ApartmentOwnerView;
import org.example.view.ApartmentPeopleView;
import org.example.view.ApartmentResidentView;
import org.example.view.ApartmentView;
import org.example.view.BuildingDueView;
import org.example.view.BuildingEmployeeView;
import org.example.view.BuildingPaidView;
import org.example.view.BuildingView;
import org.example.view.CompanyDueView;
import org.example.view.CompanyEmployeeView;
import org.example.view.CompanyEmployeesView;
import org.example.view.CompanyRevenueView;
import org.example.view.CompanyView;
import org.example.view.ContractView;
import org.example.view.ContractsFeeView;
import org.example.view.EmployeeBuildingsView;
import org.example.view.EmployeeDueView;
import org.example.view.EmployeePaidView;
import org.example.view.PaymentView;
import org.example.view.PersonView;
import org.example.view.ResidentView;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        ICompanyService companyService = new CompanyService();
        IBuildingService buildingService = new BuildingService();
        IPersonService personService = new PersonService();
        IApartmentService apartmentService = new ApartmentService();
        IApartmentOwnerService apartmentOwnerService = new ApartmentOwnerService();
        IApartmentResidentService apartmentResidentService = new ApartmentResidentService();
        ICompanyEmployeeService companyEmployeeService = new CompanyEmployeeService();
        IContractService contractService = new ContractService();
        ContractsFeeRepository contractsFeeRepository = new ContractsFeeRepository();
        ContractRepository contractRepository = new ContractRepository();
        IPaymentService paymentService = new PaymentService();
        IReportService reportService = new ReportService();

        resetDatabase();

        printSection("1. Компании CRUD");
        Company c1 = companyService.createCompany("Alpha Management");
        Company c2 = companyService.createCompany("Beta Homes");
        Company c3 = companyService.createCompany("Gamma Services");
        System.out.println("След създаване:");
        printCompanies(companyService.getAllCompanies());

        String c2OldName = c2.getName();
        String c2NewName = "Beta Properties";
        System.out.println("Редакция на фирма: id=" + c2.getId()
                + ", име: '" + c2OldName + "' -> '" + c2NewName + "'");
        companyService.updateCompany(c2.getId(), new CompanyUpdateRequest(c2NewName));
        System.out.println("След редакция:");
        printCompanies(companyService.getAllCompanies());

        System.out.println("Изтриване на фирма: id=" + c3.getId()
                + ", име='" + c3.getName() + "'");
        companyService.deleteCompany(c3.getId());
        System.out.println("След изтриване:");
        printCompanies(companyService.getAllCompanies());

        printSection("2. Сгради CRUD");
        Building b1 = buildingService.createBuilding("Shipka 12", 8, 1800.0, 220.0);
        Building b2 = buildingService.createBuilding("Maritsa 3", 4, 900.0, 90.0);
        Building b3 = buildingService.createBuilding("Vitosha 25", 6, 1500.0, 160.0);
        Building b4 = buildingService.createBuilding("Rila 8", 10, 2400.0, 260.0);
        Building b5 = buildingService.createBuilding("Bulgaria 5", 12, 3000.0, 320.0);
        Building b6 = buildingService.createBuilding("Tsar Simeon 18", 7, 1600.0, 180.0);
        System.out.println("След създаване:");
        printBuildings(buildingService.getAllBuildings());

        BuildingUpdateRequest bUpdate = new BuildingUpdateRequest();
        bUpdate.setAddress("Shipka 12A");
        bUpdate.setFloors(9);
        System.out.println("Редакция на сграда: id=" + b1.getId()
                + ", адрес: '" + b1.getAddress() + "' -> '" + bUpdate.getAddress() + "'"
                + ", етажи: " + b1.getFloors() + " -> " + bUpdate.getFloors());
        buildingService.updateBuilding(b1.getId(), bUpdate);
        System.out.println("След редакция:");
        printBuildings(buildingService.getAllBuildings());

        System.out.println("Изтриване на сграда: id=" + b6.getId()
                + ", адрес='" + b6.getAddress() + "'");
        buildingService.deleteBuilding(b6.getId());
        System.out.println("След изтриване:");
        printBuildings(buildingService.getAllBuildings());

        printSection("2.1 Апартаменти (разпределени в сградите)");
        List<Apartment> createdApartments = new ArrayList<>();
        List<Long> buildingIds = List.of(b1.getId(), b2.getId(), b3.getId(), b4.getId(), b5.getId());
        for (int i = 1; i <= 20; i++) {
            Long buildingId = buildingIds.get((i - 1) % buildingIds.size());
            Apartment apt = apartmentService.createApartment(
                    buildingId,
                    "A-" + i,
                    (i % 10) + 1,
                    60 + (i * 2.5),
                    i % 3
            );
            createdApartments.add(apt);
        }
        List<Apartment> sortedApartments = createdApartments.stream()
                .sorted(Comparator
                        .comparing((Apartment a) -> a.getBuilding() == null ? "" : a.getBuilding().getAddress())
                        .thenComparing(a -> a.getNumber() == null ? "" : a.getNumber())
                        .thenComparing(a -> a.getId() == null ? 0L : a.getId()))
                .toList();
        printApartments(sortedApartments);

        printSection("3. Хора CRUD");
        Person p1 = personService.createPerson("Azis", "Boyanov", LocalDate.of(1982, 3, 7), "azis@example.com");
        Person p2 = personService.createPerson("Preslava", "Koleva", LocalDate.of(1984, 6, 26), "preslava@example.com");
        Person p3 = personService.createPerson("Galena", "Dimitrova", LocalDate.of(1985, 5, 21), "galena@example.com");
        Person p4 = personService.createPerson("Desislava", "Ivanova", LocalDate.of(1979, 3, 18), "desislava@example.com");
        Person p5 = personService.createPerson("Andrea", "Kostadinova", LocalDate.of(1987, 1, 23), "andrea@example.com");
        Person p6 = personService.createPerson("Maria", "Panayotova", LocalDate.of(1982, 1, 13), "maria@example.com");
        Person p7 = personService.createPerson("Kameliya", "Todorova", LocalDate.of(1971, 10, 10), "kameliya@example.com");
        Person p8 = personService.createPerson("Toni", "Dacheva", LocalDate.of(1969, 9, 3), "toni@example.com");
        Person p9 = personService.createPerson("Reni", "Georgieva", LocalDate.of(1973, 6, 2), "reni@example.com");
        Person p10 = personService.createPerson("Emanuela", "Todorova", LocalDate.of(1981, 11, 8), "emanuela@example.com");
        Person p11 = personService.createPerson("Milena", "Koleva", LocalDate.of(1986, 4, 14), "milena@example.com");
        Person p12 = personService.createPerson("Elena", "Georgieva", LocalDate.of(1990, 7, 5), "elena@example.com");
        Person p13 = personService.createPerson("Ivana", "Dimitrova", LocalDate.of(1992, 12, 2), "ivana@example.com");
        System.out.println("След създаване:");
        printPersons(personService.getAllPersons());

        PersonUpdateRequest pUpdate = new PersonUpdateRequest();
        pUpdate.setLastName("Dimitrova-Vasileva");
        System.out.println("Редакция на човек: id=" + p3.getId()
                + ", фамилия: '" + p3.getLastName() + "' -> '" + pUpdate.getLastName() + "'");
        personService.updatePerson(p3.getId(), pUpdate);
        System.out.println("След редакция:");
        printPersons(personService.getAllPersons());

        System.out.println("Изтриване на човек: id=" + p13.getId()
                + ", име='" + fullName(p13) + "'");
        personService.deletePerson(p13.getId());
        System.out.println("След изтриване:");
        printPersons(personService.getAllPersons());

        printSection("3.1 Собственици и живущи CRUD");
        List<Long> ownerPersonIds = List.of(p1.getId(), p2.getId(), p3.getId(), p4.getId(), p5.getId());
        ApartmentOwner firstOwnerLink = apartmentOwnerService.addOwnerToApartment(
                createdApartments.get(0).getId(), ownerPersonIds.get(0));
        for (int i = 1; i < createdApartments.size(); i++) {
            apartmentOwnerService.addOwnerToApartment(
                    createdApartments.get(i).getId(),
                    ownerPersonIds.get(i % ownerPersonIds.size()));
        }
        System.out.println("Собственици след създаване:");
        printApartmentOwners(apartmentOwnerService.getAllOwnerLinks());

        ApartmentOwnerUpdateRequest ownerUpdate = new ApartmentOwnerUpdateRequest();
        ownerUpdate.setPersonId(p2.getId());
        System.out.println("Редакция на собственик: linkId=" + firstOwnerLink.getId()
                + ", нов personId=" + ownerUpdate.getPersonId());
        apartmentOwnerService.updateOwnerLink(firstOwnerLink.getId(), ownerUpdate);
        List<ApartmentOwner> ownerLinks = apartmentOwnerService.getAllOwnerLinks();
        if (!ownerLinks.isEmpty()) {
            ApartmentOwner toRemove = ownerLinks.get(ownerLinks.size() - 1);
            Long removedApartmentId = toRemove.getApartment() == null ? null : toRemove.getApartment().getId();
            System.out.println("Изтриване на собственик: linkId=" + toRemove.getId()
                    + ", apartmentId=" + removedApartmentId
                    + ", personId=" + (toRemove.getPerson() == null ? "" : toRemove.getPerson().getId()));
            apartmentOwnerService.removeOwnerLink(toRemove.getId());
            if (removedApartmentId != null) {
                System.out.println("Добавяне на нов собственик към apartmentId=" + removedApartmentId
                        + ", personId=" + p5.getId());
                apartmentOwnerService.addOwnerToApartment(removedApartmentId, p5.getId());
            }
        }
        System.out.println("Собственици след редакция/изтриване:");
        printApartmentOwners(apartmentOwnerService.getAllOwnerLinks());

        List<Long> residentPersonIds = List.of(p6.getId(), p7.getId(), p8.getId(), p9.getId(), p10.getId(), p11.getId());
        ApartmentResident firstResidentLink = null;
        ApartmentResident lastResidentLink = null;
        int r = 0;
        for (Apartment apt : createdApartments) {
            for (int j = 0; j < 2; j++) {
                Long personId = residentPersonIds.get(r % residentPersonIds.size());
                ApartmentResident link = apartmentResidentService.addResidentToApartment(
                        apt.getId(),
                        personId,
                        r % 2 == 0);
                if (firstResidentLink == null) {
                    firstResidentLink = link;
                }
                lastResidentLink = link;
                r++;
            }
        }
        System.out.println("Живущи след създаване:");
        printApartmentResidents(apartmentResidentService.getAllResidentLinks());

        if (firstResidentLink != null) {
            ApartmentResidentUpdateRequest residentUpdate = new ApartmentResidentUpdateRequest();
            residentUpdate.setLiftUsed(false);
            System.out.println("Редакция на живущ: linkId=" + firstResidentLink.getId()
                    + ", lift=false");
            apartmentResidentService.updateResidentLink(firstResidentLink.getId(), residentUpdate);
        }
        if (lastResidentLink != null) {
            System.out.println("Изтриване на живущ: linkId=" + lastResidentLink.getId());
            apartmentResidentService.removeResidentLink(lastResidentLink.getId());
        }
        System.out.println("Живущи след редакция/изтриване:");
        printApartmentResidents(apartmentResidentService.getAllResidentLinks());

        System.out.println("Апартаменти + собственици + живущи:");
        printApartmentPeople(reportService.getApartmentsWithPeople());

        printSection("4. Служители CRUD");
        CompanyEmployee ce1 = companyEmployeeService.addEmployeeToCompany(c1.getId(), p6.getId());
        CompanyEmployee ce2 = companyEmployeeService.addEmployeeToCompany(c1.getId(), p7.getId());
        CompanyEmployee ce3 = companyEmployeeService.addEmployeeToCompany(c1.getId(), p8.getId());
        CompanyEmployee ce4 = companyEmployeeService.addEmployeeToCompany(c1.getId(), p9.getId());
        CompanyEmployee ce5 = companyEmployeeService.addEmployeeToCompany(c2.getId(), p10.getId());
        CompanyEmployee ce6 = companyEmployeeService.addEmployeeToCompany(c2.getId(), p11.getId());
        CompanyEmployee tempLink = companyEmployeeService.addEmployeeToCompany(c1.getId(), p12.getId());
        System.out.println("Служители след създаване:");
        printCompanyEmployeeLinks(companyEmployeeService.getAllEmployeeLinks());

        System.out.println("Преместваме временно служител: linkId=" + tempLink.getId()
                + ", от фирма " + c1.getId() + " към фирма " + c2.getId());
        CompanyEmployeeUpdateRequest ceUpdate = new CompanyEmployeeUpdateRequest();
        ceUpdate.setCompanyId(c2.getId());
        companyEmployeeService.updateEmployeeLink(tempLink.getId(), ceUpdate);
        printCompanyEmployeeLinks(companyEmployeeService.getAllEmployeeLinks());
        System.out.println("Премахваме временния служител: linkId=" + tempLink.getId());
        companyEmployeeService.removeEmployeeLink(tempLink.getId());
        System.out.println("Служители след редакция/изтриване:");
        printCompanyEmployeeLinks(companyEmployeeService.getAllEmployeeLinks());

        System.out.println("Фирми и служители:");
        printCompanyEmployees(reportService.getCompaniesWithEmployees());

        printSection("5-6. Договори и такси + разпределение");
        List<Contract> createdContracts = new ArrayList<>();
        Map<String, BigDecimal> feesC1 = Map.of(
                ContractService.FEE_PRICE_PER_SQM, new BigDecimal("1.10"),
                ContractService.FEE_LIFT, new BigDecimal("4.50"),
                ContractService.FEE_PET, new BigDecimal("2.80")
        );
        Map<String, BigDecimal> feesC2 = Map.of(
                ContractService.FEE_PRICE_PER_SQM, new BigDecimal("1.30"),
                ContractService.FEE_LIFT, new BigDecimal("5.20"),
                ContractService.FEE_PET, new BigDecimal("3.10")
        );
        createdContracts.add(contractService.createContract(c1.getId(), b1.getId(), 15, feesC1));
        createdContracts.add(contractService.createContract(c1.getId(), b2.getId(), 15, feesC1));
        createdContracts.add(contractService.createContract(c1.getId(), b3.getId(), 15, feesC1));
        createdContracts.add(contractService.createContract(c1.getId(), b4.getId(), 15, feesC1));
        createdContracts.add(contractService.createContract(c2.getId(), b5.getId(), 15, feesC2));
        createdContracts = contractRepository.findByIdsWithDetails(
                createdContracts.stream().map(Contract::getId).toList());
        System.out.println("Разпределение след създаване на договори:");
        printContracts(createdContracts);
        System.out.println("Обслужвани сгради по служител (фирма " + c1.getId() + "):");
        printEmployeeBuildings(reportService.getEmployeesByBuildingCount(c1.getId()));
        for (Contract c : createdContracts) {
            System.out.println("Такси за договор " + c.getId() + ":");
            printContractFees(contractsFeeRepository.findByContractIdOrdered(c.getId()));
        }

        printSection("5.1 Напускане на служител и преразпределение");
        System.out.println("Преди напускане:");
        printContracts(createdContracts);
        System.out.println("Фирми и служители (преди напускане):");
        printCompanyEmployees(reportService.getCompaniesWithEmployees());
        System.out.println("Обслужвани сгради по служител (фирма " + c1.getId() + "):");
        printEmployeeBuildings(reportService.getEmployeesByBuildingCount(c1.getId()));

        System.out.println("Напуска служител: " + fullName(p7));
        companyEmployeeService.removeEmployeeLink(ce2.getId());
        List<Contract> reassigned = contractService.reassignContractsForEmployee(c1.getId(), p7.getId());
        System.out.println("Преразпределени договори: " + reassigned.size());
        if (!reassigned.isEmpty()) {
            List<Contract> refreshedReassigned = contractRepository.findByIdsWithDetails(
                    reassigned.stream().map(Contract::getId).toList());
            printContracts(refreshedReassigned);
        }
        List<Contract> refreshedContracts = new ArrayList<>();
        refreshedContracts.addAll(contractRepository.findByCompany(c1.getId()));
        refreshedContracts.addAll(contractRepository.findByCompany(c2.getId()));
        refreshedContracts = contractRepository.findByIdsWithDetails(
                refreshedContracts.stream().map(Contract::getId).toList());
        System.out.println("След напускане и преразпределение:");
        printContracts(refreshedContracts);
        System.out.println("Фирми и служители след напускане:");
        printCompanyEmployees(reportService.getCompaniesWithEmployees());
        System.out.println("Обслужвани сгради по служител (фирма " + c1.getId() + "):");
        printEmployeeBuildings(reportService.getEmployeesByBuildingCount(c1.getId()));

        printSection("7. Плащания");
        List<Payment> payments = new ArrayList<>();
        Apartment pay1 = createdApartments.stream()
                .filter(a -> a.getBuilding() != null && a.getBuilding().getId().equals(b1.getId()))
                .findFirst()
                .orElse(createdApartments.get(0));
        BigDecimal due1 = paymentService.calculateDueForApartment(pay1.getId());
        try {
            paymentService.payApartment(pay1.getId(), due1.subtract(new BigDecimal("1.00")), LocalDateTime.now());
        } catch (RuntimeException ex) {
            System.out.println("Частично плащане отказано: " + ex.getMessage());
        }
        payments.add(paymentService.payApartment(pay1.getId(), due1, LocalDateTime.now()));

        Apartment pay2 = createdApartments.stream()
                .filter(a -> a.getBuilding() != null && a.getBuilding().getId().equals(b3.getId()))
                .findFirst()
                .orElse(createdApartments.get(1));
        BigDecimal due2 = paymentService.calculateDueForApartment(pay2.getId());
        payments.add(paymentService.payApartment(pay2.getId(), due2, LocalDateTime.now()));

        Apartment pay3 = createdApartments.stream()
                .filter(a -> a.getBuilding() != null && a.getBuilding().getId().equals(b2.getId()))
                .findFirst()
                .orElse(createdApartments.get(2));
        BigDecimal due3 = paymentService.calculateDueForApartment(pay3.getId());
        payments.add(paymentService.payApartment(pay3.getId(), due3, LocalDateTime.now()));

        Apartment pay4 = createdApartments.stream()
                .filter(a -> a.getBuilding() != null && a.getBuilding().getId().equals(b5.getId()))
                .findFirst()
                .orElse(createdApartments.get(3));
        BigDecimal due4 = paymentService.calculateDueForApartment(pay4.getId());
        payments.add(paymentService.payApartment(pay4.getId(), due4, LocalDateTime.now()));

        Apartment pay5 = createdApartments.stream()
                .filter(a -> a.getBuilding() != null && a.getBuilding().getId().equals(b5.getId()))
                .skip(1)
                .findFirst()
                .orElse(pay4);
        BigDecimal due5 = paymentService.calculateDueForApartment(pay5.getId());
        payments.add(paymentService.payApartment(pay5.getId(), due5, LocalDateTime.now()));
        printPayments(payments);

        printSection("8. Филтриране и сортиране");
        System.out.println("Компании по приход:");
        List<CompanyRevenueView> companyRevenue = reportService.getCompaniesByRevenue();
        System.out.println("Общ брой: " + companyRevenue.size());
        printCompanyRevenues(companyRevenue);
        System.out.println("Служители по име (фирма " + c1.getId() + "):");
        List<EmployeeBuildingsView> employeesByName = reportService.getEmployeesByName(c1.getId());
        System.out.println("Общ брой: " + employeesByName.size());
        printEmployeeBuildings(employeesByName);
        System.out.println("Служители по брой обслужвани сгради (фирма " + c1.getId() + "):");
        List<EmployeeBuildingsView> employeesByBuildings = reportService.getEmployeesByBuildingCount(c1.getId());
        System.out.println("Общ брой: " + employeesByBuildings.size());
        printEmployeeBuildings(employeesByBuildings);
        System.out.println("Живущи по име (сграда " + b1.getId() + "):");
        List<ResidentView> residentsByName = reportService.getResidentsByName(b1.getId());
        System.out.println("Общ брой: " + residentsByName.size());
        printResidents(residentsByName);
        System.out.println("Живущи по възраст (сграда " + b1.getId() + "):");
        List<ResidentView> residentsByAge = reportService.getResidentsByAge(b1.getId());
        System.out.println("Общ брой: " + residentsByAge.size());
        printResidents(residentsByAge);

        printSection("9. Обобщени и подробни справки");
        System.out.println("Общ брой обслужвани сгради по служител (фирма " + c1.getId() + "):");
        List<EmployeeBuildingsView> employeesWithCounts = reportService.getEmployeesByBuildingCount(c1.getId());
        System.out.println("Общ брой: " + employeesWithCounts.size());
        printEmployeeBuildings(employeesWithCounts);
        System.out.println("Списък обслужвани сгради по служител (фирма " + c1.getId() + "):");
        List<BuildingEmployeeView> buildingEmployees = reportService.getBuildingsByEmployees(c1.getId());
        System.out.println("Общ брой записи: " + buildingEmployees.size());
        printBuildingEmployees(buildingEmployees);

        System.out.println("Апартаменти в сграда " + b1.getId() + ":");
        List<ApartmentView> apartmentsInBuilding = reportService.getApartmentsByBuilding(b1.getId());
        System.out.println("Общ брой: " + apartmentsInBuilding.size());
        printApartmentViews(apartmentsInBuilding);
        System.out.println("Живущи в сграда " + b1.getId() + ":");
        List<ResidentView> residentsInBuilding = reportService.getResidentsByName(b1.getId());
        System.out.println("Общ брой: " + residentsInBuilding.size());
        printResidents(residentsInBuilding);

        System.out.println("Суми за плащане (по фирма):");
        List<CompanyDueView> companyDues = reportService.getCompaniesDue();
        System.out.println("Общ брой: " + companyDues.size());
        printCompanyDues(companyDues);
        System.out.println("Суми за плащане (по сграда):");
        List<BuildingDueView> buildingDues = reportService.getBuildingsDue();
        System.out.println("Общ брой: " + buildingDues.size());
        printBuildingDues(buildingDues);
        System.out.println("Суми за плащане (по служител, фирма " + c1.getId() + "):");
        List<EmployeeDueView> employeeDues = reportService.getEmployeesDue(c1.getId());
        System.out.println("Общ брой: " + employeeDues.size());
        printEmployeeDues(employeeDues);

        System.out.println("Платени суми (по фирма):");
        System.out.println("Общ брой: " + companyRevenue.size());
        printCompanyRevenues(companyRevenue);
        System.out.println("Платени суми (по сграда):");
        List<BuildingPaidView> buildingPaid = reportService.getBuildingsPaid();
        System.out.println("Общ брой: " + buildingPaid.size());
        printBuildingPaid(buildingPaid);
        System.out.println("Платени суми (по служител, фирма " + c1.getId() + "):");
        List<EmployeePaidView> employeePaid = reportService.getEmployeesPaid(c1.getId());
        System.out.println("Общ брой: " + employeePaid.size());
        printEmployeePaid(employeePaid);

        JpaUtil.shutdown();
    }

    private static void printSection(String title) {
        System.out.println();
        System.out.println("==== " + title + " ====");
    }

    private static void printCompanies(List<Company> companies) {
        if (companies == null || companies.isEmpty()) {
            System.out.println("(no companies)");
            return;
        }
        List<CompanyView> rows = companies.stream().map(CompanyView::new).toList();
        System.out.println(TableRenderer.renderAsAsciiTable(rows));
    }

    private static void printBuildings(List<Building> buildings) {
        if (buildings == null || buildings.isEmpty()) {
            System.out.println("(no buildings)");
            return;
        }
        List<BuildingView> rows = buildings.stream().map(BuildingView::new).toList();
        System.out.println(TableRenderer.renderAsAsciiTable(rows));
    }

    private static void printPersons(List<Person> persons) {
        if (persons == null || persons.isEmpty()) {
            System.out.println("(no persons)");
            return;
        }
        List<PersonView> rows = persons.stream().map(PersonView::new).toList();
        System.out.println(TableRenderer.renderAsAsciiTable(rows));
    }

    private static void printApartments(List<Apartment> apartments) {
        if (apartments == null || apartments.isEmpty()) {
            System.out.println("(no apartments)");
            return;
        }
        List<ApartmentView> rows = apartments.stream().map(ApartmentView::new).toList();
        System.out.println(TableRenderer.renderAsAsciiTable(rows));
    }

    private static void printApartmentViews(List<ApartmentView> rows) {
        if (rows == null || rows.isEmpty()) {
            System.out.println("(no apartments)");
            return;
        }
        System.out.println(TableRenderer.renderAsAsciiTable(rows));
    }

    private static void printApartmentOwners(List<ApartmentOwner> links) {
        if (links == null || links.isEmpty()) {
            System.out.println("(no apartment owners)");
            return;
        }
        List<ApartmentOwnerView> rows = links.stream().map(ApartmentOwnerView::new).toList();
        System.out.println(TableRenderer.renderAsAsciiTable(rows));
    }

    private static void printApartmentResidents(List<ApartmentResident> links) {
        if (links == null || links.isEmpty()) {
            System.out.println("(no apartment residents)");
            return;
        }
        List<ApartmentResidentView> rows = links.stream().map(ApartmentResidentView::new).toList();
        System.out.println(TableRenderer.renderAsAsciiTable(rows));
    }

    private static void printCompanyEmployeeLinks(List<CompanyEmployee> links) {
        if (links == null || links.isEmpty()) {
            System.out.println("(no company employees)");
            return;
        }
        List<CompanyEmployeeView> rows = links.stream().map(CompanyEmployeeView::new).toList();
        System.out.println(TableRenderer.renderAsAsciiTable(rows));
    }

    private static void printCompanyEmployees(List<CompanyEmployeesView> rows) {
        if (rows == null || rows.isEmpty()) {
            System.out.println("(no companies)");
            return;
        }
        System.out.println(TableRenderer.renderAsAsciiTable(rows));
    }

    private static void printContracts(List<Contract> contracts) {
        if (contracts == null || contracts.isEmpty()) {
            System.out.println("(no contracts)");
            return;
        }
        List<ContractView> rows = contracts.stream().map(ContractView::new).toList();
        System.out.println(TableRenderer.renderAsAsciiTable(rows));
    }

    private static void printContractFees(List<org.example.entity.ContractsFee> fees) {
        if (fees == null || fees.isEmpty()) {
            System.out.println("(no contract fees)");
            return;
        }
        List<ContractsFeeView> rows = fees.stream().map(ContractsFeeView::new).toList();
        System.out.println(TableRenderer.renderAsAsciiTable(rows));
    }

    private static void printPayments(List<Payment> payments) {
        if (payments == null || payments.isEmpty()) {
            System.out.println("(no payments)");
            return;
        }
        List<PaymentView> rows = payments.stream().map(PaymentView::new).toList();
        System.out.println(TableRenderer.renderAsAsciiTable(rows));
    }

    private static void printCompanyRevenues(List<CompanyRevenueView> rows) {
        if (rows == null || rows.isEmpty()) {
            System.out.println("(no company revenues)");
            return;
        }
        System.out.println(TableRenderer.renderAsAsciiTable(rows));
    }

    private static void printCompanyDues(List<CompanyDueView> rows) {
        if (rows == null || rows.isEmpty()) {
            System.out.println("(no company dues)");
            return;
        }
        System.out.println(TableRenderer.renderAsAsciiTable(rows));
    }

    private static void printBuildingDues(List<BuildingDueView> rows) {
        if (rows == null || rows.isEmpty()) {
            System.out.println("(no building dues)");
            return;
        }
        System.out.println(TableRenderer.renderAsAsciiTable(rows));
    }

    private static void printBuildingPaid(List<BuildingPaidView> rows) {
        if (rows == null || rows.isEmpty()) {
            System.out.println("(no building paid)");
            return;
        }
        System.out.println(TableRenderer.renderAsAsciiTable(rows));
    }

    private static void printEmployeeBuildings(List<EmployeeBuildingsView> rows) {
        if (rows == null || rows.isEmpty()) {
            System.out.println("(no employees)");
            return;
        }
        System.out.println(TableRenderer.renderAsAsciiTable(rows));
    }

    private static void printEmployeeDues(List<EmployeeDueView> rows) {
        if (rows == null || rows.isEmpty()) {
            System.out.println("(no employee dues)");
            return;
        }
        System.out.println(TableRenderer.renderAsAsciiTable(rows));
    }

    private static void printEmployeePaid(List<EmployeePaidView> rows) {
        if (rows == null || rows.isEmpty()) {
            System.out.println("(no employee paid)");
            return;
        }
        System.out.println(TableRenderer.renderAsAsciiTable(rows));
    }

    private static void printBuildingEmployees(List<BuildingEmployeeView> rows) {
        if (rows == null || rows.isEmpty()) {
            System.out.println("(no building employees)");
            return;
        }
        System.out.println(TableRenderer.renderAsAsciiTable(rows));
    }

    private static void printResidents(List<ResidentView> rows) {
        if (rows == null || rows.isEmpty()) {
            System.out.println("(no residents)");
            return;
        }
        System.out.println(TableRenderer.renderAsAsciiTable(rows));
    }

    private static void printApartmentPeople(List<ApartmentPeopleView> rows) {
        if (rows == null || rows.isEmpty()) {
            System.out.println("(no apartment people)");
            return;
        }
        System.out.println(TableRenderer.renderAsAsciiTable(rows));
    }

    private static String fullName(Person person) {
        if (person == null) {
            return "";
        }
        String fn = person.getFirstName() == null ? "" : person.getFirstName();
        String ln = person.getLastName() == null ? "" : person.getLastName();
        return (fn + " " + ln).trim();
    }

    private static void resetDatabase() {
        if (!Boolean.parseBoolean(System.getProperty("demo.resetDb", "true"))) {
            System.out.println("Skipping database reset (set -Ddemo.resetDb=true to enable).");
            return;
        }
        System.out.println("Resetting database (demo-only, PostgreSQL-specific TRUNCATE).");
        var em = JpaUtil.getEntityManager();
        try {
            em.getTransaction().begin();
            em.createNativeQuery(
                    "TRUNCATE TABLE " +
                            "contractsfees, " +
                            "payments, " +
                            "apartmentsowners, " +
                            "apartmentsresidents, " +
                            "companyemployees, " +
                            "contract, " +
                            "apartments, " +
                            "company, " +
                            "persons, " +
                            "building " +
                            "RESTART IDENTITY CASCADE"
            ).executeUpdate();
            em.getTransaction().commit();
        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }
}
