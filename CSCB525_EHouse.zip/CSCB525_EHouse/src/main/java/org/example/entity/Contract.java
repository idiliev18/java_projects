package org.example.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

@Entity
@Table(
        name = "contract",
        uniqueConstraints = @UniqueConstraint(columnNames = "buildingId")
)
public class Contract {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Min(1)
    @Max(31)
    @Column(nullable = false)
    private int paymentDay;

    @ManyToOne(optional = false)
    @JoinColumn(name = "companyId", nullable = false)
    private Company company;

    @ManyToOne(optional = false)
    @JoinColumn(name = "buildingId", nullable = false)
    private Building building;

    @ManyToOne(optional = false)
    @JoinColumn(name = "employeeId", nullable = false)
    private Person employee;

    public Contract() {
    }

    public Long getId() {
        return id;
    }

    public int getPaymentDay() {
        return paymentDay;
    }

    public void setPaymentDay(int paymentDay) {
        this.paymentDay = paymentDay;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public Building getBuilding() {
        return building;
    }

    public void setBuilding(Building building) {
        this.building = building;
    }

    public Person getEmployee() {
        return employee;
    }

    public void setEmployee(Person employee) {
        this.employee = employee;
    }
}
