package org.example.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(
        name = "apartmentsresidents",
        uniqueConstraints = @UniqueConstraint(columnNames = {"apartmentId", "personId"})
)
public class ApartmentResident {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "apartmentId", nullable = false)
    private Apartment apartment;

    @ManyToOne(optional = false)
    @JoinColumn(name = "personId", nullable = false)
    private Person person;

    @Column(nullable = false)
    private boolean isLiftUsed;

    public ApartmentResident() {
    }

    public Long getId() {
        return id;
    }

    public Apartment getApartment() {
        return apartment;
    }

    public void setApartment(Apartment apartment) {
        this.apartment = apartment;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public boolean isLiftUsed() {
        return isLiftUsed;
    }

    public void setLiftUsed(boolean liftUsed) {
        isLiftUsed = liftUsed;
    }
}
