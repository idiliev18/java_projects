package org.example.view;

import org.example.entity.Building;
import org.example.entity.Person;
import org.example.utils.table.TableColumn;

public class BuildingEmployeeView {
    @TableColumn(header = "Employee", order = 1, width = 20)
    private final String employeeName;

    @TableColumn(header = "BuildingId", order = 2, width = 10)
    private final String buildingId;

    @TableColumn(header = "Address", order = 3, width = 30)
    private final String address;

    public BuildingEmployeeView(Person employee, Building building) {
        String fn = employee.getFirstName() == null ? "" : employee.getFirstName();
        String ln = employee.getLastName() == null ? "" : employee.getLastName();
        this.employeeName = (fn + " " + ln).trim();
        this.buildingId = building.getId() == null ? "" : building.getId().toString();
        this.address = building.getAddress();
    }
}
