package org.example.view;

import org.example.utils.table.TableColumn;

public class CompanyEmployeesView {
    @TableColumn(header = "CompanyId", order = 1, width = 8)
    private final String companyId;

    @TableColumn(header = "Company", order = 2, width = 20)
    private final String companyName;

    @TableColumn(header = "Employees", order = 3, width = 40)
    private final String employees;

    public CompanyEmployeesView(Long companyId, String companyName, String employees) {
        this.companyId = companyId == null ? "" : companyId.toString();
        this.companyName = companyName == null ? "" : companyName;
        this.employees = employees == null ? "" : employees;
    }

    public String getCompanyName() {
        return companyName;
    }
}
