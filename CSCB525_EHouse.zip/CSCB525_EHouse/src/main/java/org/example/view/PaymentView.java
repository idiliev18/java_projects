package org.example.view;

import org.example.entity.Payment;
import org.example.utils.table.TableColumn;

import java.time.format.DateTimeFormatter;

public class PaymentView {
    @TableColumn(header = "ID", order = 1, width = 4)
    private final String id;

    @TableColumn(header = "ApartmentId", order = 2, width = 10)
    private final String apartmentId;

    @TableColumn(header = "Amount", order = 3, width = 8)
    private final String amount;

    @TableColumn(header = "Paid At", order = 4, width = 19)
    private final String paymentDate;

    public PaymentView(Payment payment) {
        this.id = payment.getId() == null ? "" : payment.getId().toString();
        this.apartmentId = payment.getApartment() == null || payment.getApartment().getId() == null
                ? ""
                : payment.getApartment().getId().toString();
        this.amount = payment.getAmount() == null ? "" : payment.getAmount().toString();
        if (payment.getPaymentDate() != null) {
            this.paymentDate = payment.getPaymentDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        } else {
            this.paymentDate = "";
        }
    }
}
