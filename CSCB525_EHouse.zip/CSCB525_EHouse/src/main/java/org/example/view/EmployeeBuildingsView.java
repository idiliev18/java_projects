package org.example.view;

import org.example.entity.Person;
import org.example.utils.table.TableColumn;

public class EmployeeBuildingsView {
    @TableColumn(header = "ID", order = 1, width = 4)
    private final String id;

    @TableColumn(header = "First Name", order = 2, width = 12)
    private final String firstName;

    @TableColumn(header = "Last Name", order = 3, width = 12)
    private final String lastName;

    @TableColumn(header = "Buildings", order = 4, width = 9)
    private final String buildingCount;

    public EmployeeBuildingsView(Person p, long count) {
        this.id = p.getId() == null ? "" : p.getId().toString();
        this.firstName = p.getFirstName();
        this.lastName = p.getLastName();
        this.buildingCount = String.valueOf(count);
    }
}
