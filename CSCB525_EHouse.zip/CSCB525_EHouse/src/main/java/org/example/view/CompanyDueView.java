package org.example.view;

import org.example.entity.Company;
import org.example.utils.table.TableColumn;

import java.math.BigDecimal;

public class CompanyDueView {
    @TableColumn(header = "ID", order = 1, width = 4)
    private final String id;

    @TableColumn(header = "Company", order = 2, width = 20)
    private final String name;

    @TableColumn(header = "Due", order = 3, width = 10)
    private final String due;

    public CompanyDueView(Company company, BigDecimal due) {
        this.id = company.getId() == null ? "" : company.getId().toString();
        this.name = company.getName();
        this.due = due == null ? "0" : due.toString();
    }
}
