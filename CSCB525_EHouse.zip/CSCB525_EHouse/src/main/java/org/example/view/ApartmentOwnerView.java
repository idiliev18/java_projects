package org.example.view;

import org.example.entity.ApartmentOwner;
import org.example.utils.table.TableColumn;

public class ApartmentOwnerView {
    @TableColumn(header = "ID", order = 1, width = 4)
    private final String id;

    @TableColumn(header = "ApartmentId", order = 2, width = 10)
    private final String apartmentId;

    @TableColumn(header = "PersonId", order = 3, width = 8)
    private final String personId;

    public ApartmentOwnerView(ApartmentOwner link) {
        this.id = link.getId() == null ? "" : link.getId().toString();
        this.apartmentId = link.getApartment() == null || link.getApartment().getId() == null
                ? ""
                : link.getApartment().getId().toString();
        this.personId = link.getPerson() == null || link.getPerson().getId() == null
                ? ""
                : link.getPerson().getId().toString();
    }
}
