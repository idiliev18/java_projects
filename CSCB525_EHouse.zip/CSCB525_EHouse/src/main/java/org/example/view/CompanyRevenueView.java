package org.example.view;

import org.example.entity.Company;
import org.example.utils.table.TableColumn;

import java.math.BigDecimal;

public class CompanyRevenueView {
    @TableColumn(header = "ID", order = 1, width = 4)
    private final String id;

    @TableColumn(header = "Company", order = 2, width = 20)
    private final String name;

    @TableColumn(header = "Revenue", order = 3, width = 10)
    private final String revenue;

    public CompanyRevenueView(Company company, BigDecimal revenue) {
        this.id = company.getId() == null ? "" : company.getId().toString();
        this.name = company.getName();
        this.revenue = revenue == null ? "0" : revenue.toString();
    }
}
