package org.example.view;

import org.example.entity.ContractsFee;
import org.example.utils.table.TableColumn;

public class ContractsFeeView {
    @TableColumn(header = "ID", order = 1, width = 4)
    private final String id;

    @TableColumn(header = "ContractId", order = 2, width = 10)
    private final String contractId;

    @TableColumn(header = "FeeType", order = 3, width = 12)
    private final String feeType;

    @TableColumn(header = "Amount", order = 4, width = 8)
    private final String amount;

    public ContractsFeeView(ContractsFee fee) {
        this.id = fee.getId() == null ? "" : fee.getId().toString();
        this.contractId = fee.getContract() == null || fee.getContract().getId() == null
                ? ""
                : fee.getContract().getId().toString();
        this.feeType = fee.getFeeType() == null ? "" : fee.getFeeType().getName();
        this.amount = fee.getAmount() == null ? "" : fee.getAmount().toString();
    }
}
