package org.example.view;

import org.example.entity.Contract;
import org.example.utils.table.TableColumn;

public class ContractView {
    @TableColumn(header = "ID", order = 1, width = 4)
    private final String id;

    @TableColumn(header = "Company", order = 2, width = 20)
    private final String companyName;

    @TableColumn(header = "Building", order = 3, width = 30)
    private final String buildingAddress;

    @TableColumn(header = "Employee", order = 4, width = 20)
    private final String employeeName;

    @TableColumn(header = "PayDay", order = 5, width = 6)
    private final String paymentDay;

    public ContractView(Contract contract) {
        this.id = contract.getId() == null ? "" : contract.getId().toString();
        this.companyName = contract.getCompany() == null
                ? ""
                : contract.getCompany().getName();
        this.buildingAddress = contract.getBuilding() == null
                ? ""
                : contract.getBuilding().getAddress();
        String fn = contract.getEmployee() == null || contract.getEmployee().getFirstName() == null
                ? ""
                : contract.getEmployee().getFirstName();
        String ln = contract.getEmployee() == null || contract.getEmployee().getLastName() == null
                ? ""
                : contract.getEmployee().getLastName();
        this.employeeName = (fn + " " + ln).trim();
        this.paymentDay = String.valueOf(contract.getPaymentDay());
    }
}
