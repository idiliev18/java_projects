package org.example.view;

import org.example.utils.table.TableColumn;

public class ApartmentPeopleView {
    @TableColumn(header = "Apartment", order = 1, width = 30)
    private final String apartmentLabel;

    @TableColumn(header = "Owners", order = 2, width = 30)
    private final String owners;

    @TableColumn(header = "Residents", order = 3, width = 40)
    private final String residents;

    public ApartmentPeopleView(String apartmentLabel, String owners, String residents) {
        this.apartmentLabel = apartmentLabel;
        this.owners = owners;
        this.residents = residents;
    }
}
