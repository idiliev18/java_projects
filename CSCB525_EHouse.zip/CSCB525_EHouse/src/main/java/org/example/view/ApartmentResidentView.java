package org.example.view;

import org.example.entity.ApartmentResident;
import org.example.utils.table.TableColumn;

public class ApartmentResidentView {
    @TableColumn(header = "ID", order = 1, width = 4)
    private final String id;

    @TableColumn(header = "ApartmentId", order = 2, width = 10)
    private final String apartmentId;

    @TableColumn(header = "PersonId", order = 3, width = 8)
    private final String personId;

    @TableColumn(header = "Lift", order = 4, width = 4)
    private final String isLiftUsed;

    public ApartmentResidentView(ApartmentResident link) {
        this.id = link.getId() == null ? "" : link.getId().toString();
        this.apartmentId = link.getApartment() == null || link.getApartment().getId() == null
                ? ""
                : link.getApartment().getId().toString();
        this.personId = link.getPerson() == null || link.getPerson().getId() == null
                ? ""
                : link.getPerson().getId().toString();
        this.isLiftUsed = String.valueOf(link.isLiftUsed());
    }
}
