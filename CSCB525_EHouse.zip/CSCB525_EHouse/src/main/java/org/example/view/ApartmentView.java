package org.example.view;

import org.example.entity.Apartment;
import org.example.utils.table.TableColumn;

public class ApartmentView {
    @TableColumn(header = "ID", order = 1, width = 4)
    private final String id;

    @TableColumn(header = "Number", order = 2, width = 8)
    private final String number;

    @TableColumn(header = "Floor", order = 3, width = 5)
    private final String floor;

    @TableColumn(header = "Area", order = 4, width = 8)
    private final String area;

    @TableColumn(header = "Pets", order = 5, width = 4)
    private final String petCount;

    @TableColumn(header = "Building", order = 6, width = 30)
    private final String buildingAddress;

    public ApartmentView(Apartment apartment) {
        this.id = apartment.getId() == null ? "" : apartment.getId().toString();
        this.number = apartment.getNumber();
        this.floor = String.valueOf(apartment.getFloor());
        this.area = String.valueOf(apartment.getArea());
        this.petCount = String.valueOf(apartment.getPetCount());
        this.buildingAddress = apartment.getBuilding() == null
                ? ""
                : apartment.getBuilding().getAddress();
    }
}
