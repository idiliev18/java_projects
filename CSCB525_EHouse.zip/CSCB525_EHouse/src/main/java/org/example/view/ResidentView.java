package org.example.view;

import org.example.entity.Person;
import org.example.utils.table.TableColumn;

import java.time.format.DateTimeFormatter;

public class ResidentView {
    @TableColumn(header = "ID", order = 1, width = 4)
    private final String id;

    @TableColumn(header = "First Name", order = 2, width = 12)
    private final String firstName;

    @TableColumn(header = "Last Name", order = 3, width = 12)
    private final String lastName;

    @TableColumn(header = "Birth Date", order = 4, width = 10)
    private final String birthDate;

    public ResidentView(Person p) {
        this.id = p.getId() == null ? "" : p.getId().toString();
        this.firstName = p.getFirstName();
        this.lastName = p.getLastName();
        if (p.getBirthDate() != null) {
            this.birthDate = p.getBirthDate().format(DateTimeFormatter.ISO_DATE);
        } else {
            this.birthDate = "";
        }
    }
}
