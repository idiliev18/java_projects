package org.example.view;

import org.example.entity.Person;
import org.example.utils.table.TableColumn;

import java.time.format.DateTimeFormatter;

public class PersonView {
    @TableColumn(header = "ID", order = 1, width = 4)
    private final String id;

    @TableColumn(header = "First Name", order = 2, width = 12)
    private final String firstName;

    @TableColumn(header = "Last Name", order = 3, width = 12)
    private final String lastName;

    @TableColumn(header = "Birth Date", order = 4, width = 10)
    private final String birthDate;

    @TableColumn(header = "Email", order = 5, width = 20)
    private final String email;

    public PersonView(Person person) {
        this.id = person.getId() == null ? "" : person.getId().toString();
        this.firstName = person.getFirstName();
        this.lastName = person.getLastName();
        if (person.getBirthDate() != null) {
            this.birthDate = person.getBirthDate().format(DateTimeFormatter.ISO_DATE);
        } else {
            this.birthDate = "";
        }
        this.email = person.getEmail() == null ? "" : person.getEmail();
    }
}
