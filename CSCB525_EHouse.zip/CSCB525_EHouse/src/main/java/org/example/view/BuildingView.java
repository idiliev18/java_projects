package org.example.view;

import org.example.entity.Building;
import org.example.utils.table.TableColumn;

public class BuildingView {
    @TableColumn(header = "ID", order = 1, width = 4)
    private final String id;

    @TableColumn(header = "Address", order = 2, width = 30)
    private final String address;

    @TableColumn(header = "Floors", order = 3, width = 6)
    private final String floors;

    @TableColumn(header = "Build Area", order = 4, width = 10)
    private final String buildArea;

    @TableColumn(header = "Shared Area", order = 5, width = 10)
    private final String sharedArea;

    public BuildingView(Building building) {
        this.id = building.getId() == null ? "" : building.getId().toString();
        this.address = building.getAddress();
        this.floors = String.valueOf(building.getFloors());
        this.buildArea = String.valueOf(building.getBuildArea());
        this.sharedArea = String.valueOf(building.getSharedArea());
    }
}
