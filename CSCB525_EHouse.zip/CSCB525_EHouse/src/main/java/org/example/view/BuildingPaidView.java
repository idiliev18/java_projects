package org.example.view;

import org.example.entity.Building;
import org.example.utils.table.TableColumn;

import java.math.BigDecimal;

public class BuildingPaidView {
    @TableColumn(header = "ID", order = 1, width = 4)
    private final String id;

    @TableColumn(header = "Address", order = 2, width = 30)
    private final String address;

    @TableColumn(header = "Paid", order = 3, width = 10)
    private final String paid;

    public BuildingPaidView(Building building, BigDecimal paid) {
        this.id = building.getId() == null ? "" : building.getId().toString();
        this.address = building.getAddress();
        this.paid = paid == null ? "0" : paid.toString();
    }
}
