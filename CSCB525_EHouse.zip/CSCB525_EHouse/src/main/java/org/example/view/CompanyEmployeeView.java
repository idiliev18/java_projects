package org.example.view;

import org.example.entity.CompanyEmployee;
import org.example.utils.table.TableColumn;

public class CompanyEmployeeView {
    @TableColumn(header = "ID", order = 1, width = 4)
    private final String id;

    @TableColumn(header = "CompanyId", order = 2, width = 10)
    private final String companyId;

    @TableColumn(header = "PersonId", order = 3, width = 8)
    private final String personId;

    public CompanyEmployeeView(CompanyEmployee link) {
        this.id = link.getId() == null ? "" : link.getId().toString();
        this.companyId = link.getCompany() == null || link.getCompany().getId() == null
                ? ""
                : link.getCompany().getId().toString();
        this.personId = link.getPerson() == null || link.getPerson().getId() == null
                ? ""
                : link.getPerson().getId().toString();
    }
}
