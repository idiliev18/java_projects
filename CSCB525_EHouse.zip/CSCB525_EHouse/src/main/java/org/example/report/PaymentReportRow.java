package org.example.report;

import java.math.BigDecimal;

public class PaymentReportRow {
    private final Long companyId;
    private final String companyName;
    private final String employeeName;
    private final String buildingAddress;
    private final String apartmentNumber;
    private final BigDecimal amount;
    private final String paymentDate;

    public PaymentReportRow(Long companyId,
                            String companyName,
                            String employeeName,
                            String buildingAddress,
                            String apartmentNumber,
                            BigDecimal amount,
                            String paymentDate) {
        this.companyId = companyId;
        this.companyName = companyName;
        this.employeeName = employeeName;
        this.buildingAddress = buildingAddress;
        this.apartmentNumber = apartmentNumber;
        this.amount = amount;
        this.paymentDate = paymentDate;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public String getBuildingAddress() {
        return buildingAddress;
    }

    public String getApartmentNumber() {
        return apartmentNumber;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public String getPaymentDate() {
        return paymentDate;
    }
}
