package org.example.dto;

public class ApartmentOwnerUpdateRequest {
    private Long apartmentId;
    private Long personId;

    public ApartmentOwnerUpdateRequest() {
    }

    public Long getApartmentId() {
        return apartmentId;
    }

    public void setApartmentId(Long apartmentId) {
        this.apartmentId = apartmentId;
    }

    public Long getPersonId() {
        return personId;
    }

    public void setPersonId(Long personId) {
        this.personId = personId;
    }
}
