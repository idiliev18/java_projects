package org.example.dto;

public class ApartmentResidentUpdateRequest {
    private Long apartmentId;
    private Long personId;
    private Boolean liftUsed;

    public ApartmentResidentUpdateRequest() {
    }

    public Long getApartmentId() {
        return apartmentId;
    }

    public void setApartmentId(Long apartmentId) {
        this.apartmentId = apartmentId;
    }

    public Long getPersonId() {
        return personId;
    }

    public void setPersonId(Long personId) {
        this.personId = personId;
    }

    public Boolean getLiftUsed() {
        return liftUsed;
    }

    public void setLiftUsed(Boolean liftUsed) {
        this.liftUsed = liftUsed;
    }
}
