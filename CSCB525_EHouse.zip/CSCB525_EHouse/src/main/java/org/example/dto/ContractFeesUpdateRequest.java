package org.example.dto;

import java.math.BigDecimal;
import java.util.Map;

public class ContractFeesUpdateRequest {
    private Map<String, BigDecimal> fees;

    public ContractFeesUpdateRequest() {
    }

    public ContractFeesUpdateRequest(Map<String, BigDecimal> fees) {
        this.fees = fees;
    }

    public Map<String, BigDecimal> getFees() {
        return fees;
    }

    public void setFees(Map<String, BigDecimal> fees) {
        this.fees = fees;
    }
}
