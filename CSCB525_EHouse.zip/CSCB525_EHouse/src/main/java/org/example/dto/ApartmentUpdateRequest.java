package org.example.dto;

import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;

public class ApartmentUpdateRequest {
    @Size(max = 45)
    private String number;

    @PositiveOrZero
    private Integer floor;

    @Positive
    private Double area;

    @PositiveOrZero
    private Integer petCount;

    private Long buildingId;

    public ApartmentUpdateRequest() {
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Integer getFloor() {
        return floor;
    }

    public void setFloor(Integer floor) {
        this.floor = floor;
    }

    public Double getArea() {
        return area;
    }

    public void setArea(Double area) {
        this.area = area;
    }

    public Integer getPetCount() {
        return petCount;
    }

    public void setPetCount(Integer petCount) {
        this.petCount = petCount;
    }

    public Long getBuildingId() {
        return buildingId;
    }

    public void setBuildingId(Long buildingId) {
        this.buildingId = buildingId;
    }
}
