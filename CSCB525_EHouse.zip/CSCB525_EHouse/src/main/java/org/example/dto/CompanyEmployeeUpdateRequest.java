package org.example.dto;

public class CompanyEmployeeUpdateRequest {
    private Long companyId;
    private Long personId;

    public CompanyEmployeeUpdateRequest() {
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public Long getPersonId() {
        return personId;
    }

    public void setPersonId(Long personId) {
        this.personId = personId;
    }
}
